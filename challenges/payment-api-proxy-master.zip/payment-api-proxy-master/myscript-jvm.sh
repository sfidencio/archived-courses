# Clean and build the project generating the JAR
mvn clean package -DskipTests

# Check if the JAR was created successfully
if [ $? -ne 0 ]; then
    echo "Error compiling the project. Check the logs."
    exit 1
fi

# Log in to Docker Hub (replace USERNAME with your user)
echo "QWRtU2ViMjVAQCMK" | base64 -d | docker login -u sfidencio --password-stdin

## Check if the login was successful
if [ $? -ne 0 ]; then
    echo "Error logging in to Docker Hub. Check your credentials."
    exit 1
fi

# Build the Docker image (replace IMAGE_NAME with the desired name)
docker build -f Dockerfile-jvm -t sfidencio/payment-api-proxy:latest .

#Check if the image was created successfully
if [ $? -ne 0 ]; then
    echo "Error building the Docker image. Check the Dockerfile."
    exit 1
fi

# Push the image to Docker Hub
docker push sfidencio/payment-api-proxy:latest

## Check if the push was successful
if [ $? -ne 0 ]; then
    echo "Error pushing the image to Docker Hub. Check your connection."
    exit 1
fi
echo "Docker image successfully created and pushed to Docker Hub."


docker compose -f docker-compose-jvm.yaml down
docker compose -f docker-compose-jvm.yaml up -d
