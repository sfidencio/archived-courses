# 🚀 Bem-vindo ao Payment API Proxy!

Olá! Este projeto é um proxy de API de pagamentos, desenvolvido com Spring Boot, WebFlux e Redis, pronto para rodar em ambientes nativos com GraalVM. Aqui você encontra tudo o que precisa para começar, rodar e contribuir! 😃

## 📦 Sobre o Projeto

Este serviço expõe endpoints reativos para processar pagamentos, consultar status e obter resumos. Utiliza Redis para armazenamento rápido e eficiente.

## 🛠️ Tecnologias Utilizadas

- ⚡ Spring Boot WebFlux
- 🧠 Redis (Reativo)
- 🐳 Docker & Docker Compose
- 🦾 GraalVM Native Image

## 🚦 Como Rodar Localmente

1. **Pré-requisitos:**
    - Java 21+
    - Docker e Docker Compose
    - Maven

2. **Build do Projeto:**
   ```bash
   ./mvnw clean package
   ```

3. **Rodando com Docker Compose:**
   ```bash
   docker-compose up --build
   ```

4. **Acessando a API:**
    - Acesse `http://localhost:8080` para os endpoints REST.

## 🧪 Testes

Execute os testes automatizados com:
```bash
./mvnw test
```

## 🐳 Build Nativo (GraalVM)

Para gerar um binário nativo:
```bash
docker build -t payment-api-proxy .
```

## 📚 Documentação e Referências

- [Documentação Spring Boot](https://docs.spring.io/spring-boot/)
- [WebFlux](https://docs.spring.io/spring-framework/docs/current/reference/html/web-reactive.html)
- [Redis Reativo](https://docs.spring.io/spring-data/redis/docs/current/reference/html/#redis.reactive)
- [GraalVM Native Image](https://www.graalvm.org/reference-manual/native-image/)

## 📝 Endpoints da API

### `POST /payments`
Processa um pagamento, encaminhando para o melhor gateway disponível (primário ou fallback).
- Se o pagamento for processado com sucesso (HTTP 2xx), ele é salvo no Redis e retorna mensagem de sucesso.
- Se o gateway retornar 422 (pagamento já existe), retorna 422 sem tentar fallback e sem salvar no Redis.
- Em caso de erro (timeout, 5xx, etc) no primário, tenta o fallback.
- Se ambos falharem, retorna 502.

Veja o fluxo detalhado nos diagramas:
- [Diagrama de Sequência](./processPayment-sequence.png)
- [Diagrama de Atividades](./processPayment-activity.png)

### `GET /payments-summary`
Retorna um resumo dos pagamentos processados, agrupando por gateway (default e fallback), incluindo quantidade e valor total. Permite filtros opcionais por data (`from`, `to`).

### `GET /payments/{gateway}/{correlationId}`
Consulta o pagamento salvo no Redis, informando o gateway (`default` ou `fallback`) e o `correlationId` do pagamento.

### `GET /health`
Endpoint de healthcheck da aplicação, útil para monitoramento e automação.

## 🐳 Docker e Execução

O projeto possui arquivos Dockerfile e docker-compose para facilitar a execução local e em produção. O build nativo pode ser feito com GraalVM para maior performance.

## 📝 Observações Importantes

- O projeto utiliza Spring WebFlux (reativo) e Redis reativo.
- O fluxo de fallback é inteligente: só ocorre em caso de erro real no gateway primário.
- O Redis é utilizado como cache/registro rápido dos pagamentos processados.
- Os diagramas UML em PNG na raiz ilustram claramente o fluxo de processamento dos pagamentos.
- **Tunagem e ajustes de performance**: todos os parâmetros de ajuste de performance (como timeouts, URLs de gateways, configurações de Redis, limites de conexões, etc.) são feitos via variáveis de ambiente, facilitando a customização sem necessidade de alterar o código-fonte. Consulte o `docker-compose.yaml` e o `application.yaml` para exemplos de configuração.

## 🤝 Contribuindo

Contribuições são super bem-vindas! Abra uma issue ou envie um PR. Vamos juntos melhorar este projeto! 💪

## 👨‍💻 Autor

Feito com 💙 por [sfidencio].

---

> Dúvidas? Sugestões? Fique à vontade para perguntar! 😄
