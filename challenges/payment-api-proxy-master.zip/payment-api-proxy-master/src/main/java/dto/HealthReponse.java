package dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class HealthReponse {
    private boolean failing;
    private int minResponseTime;
}
