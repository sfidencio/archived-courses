package controller;

import dto.PaymentRequest;
import dto.PaymentSummary;
import dto.PaymentsSummaryResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.data.redis.core.ReactiveValueOperations;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@RestController
@Slf4j
public class PaymentController {

    @Value("${processor.payment.default.url}")
    private String defaultPaymentProcessorUrl;

    @Value("${processor.payment.fallback.url}")
    private String fallbackPaymentProcessorUrl;
    private final WebClient webClient;
    private final ReactiveValueOperations<String, PaymentRequest> valueOps;
    private ReactiveRedisTemplate<String, PaymentRequest> redisTemplate;
    private final ReactiveRedisTemplate<String, String> redisTemplateString;

    public PaymentController(WebClient.Builder webClientBuilder,
                             ReactiveRedisTemplate<String, PaymentRequest> redisTemplate,
                             ReactiveRedisTemplate<String, String> redisTemplateString) {
        this.webClient = webClientBuilder.build();
        this.redisTemplate = redisTemplate;
        this.redisTemplateString = redisTemplateString;
        this.valueOps = redisTemplate.opsForValue();
    }

    @PostMapping("/payments")
    public Mono<ResponseEntity<String>> processPayment(@RequestBody PaymentRequest paymentRequest) {

        log.info("Recebida requisição de pagamento: {}", paymentRequest);

        // Seleciona o melhor gateway e processa diretamente, sem checar duplicidade no Redis
        return this.selectBestGateway()
                .flatMap(bestGateway -> {
                    if (bestGateway == null) {
                        log.error("Nenhum gateway saudável disponível para correlationId={}", paymentRequest.getCorrelationId());
                        return Mono.just(ResponseEntity.status(502).body("Nenhum gateway saudável disponível."));
                    }
                    String primary = bestGateway;
                    String secondary = java.util.Objects.equals(bestGateway, "default") ? "fallback" : "default";
                    String endpointPrimary = java.util.Objects.equals(primary, "default") ? defaultPaymentProcessorUrl : fallbackPaymentProcessorUrl;
                    String endpointSecondary = java.util.Objects.equals(secondary, "default") ? defaultPaymentProcessorUrl : fallbackPaymentProcessorUrl;
                    String redisKeyPrimary = "payment:" + primary + ":" + paymentRequest.getCorrelationId();
                    String redisKeySecondary = "payment:" + secondary + ":" + paymentRequest.getCorrelationId();
                    paymentRequest.setCreatedAt(Instant.now().toString());

                    // Envia requisição para o gateway primário
                    Mono<ResponseEntity<String>> tryPrimary = webClient.post()
                            .uri(endpointPrimary)
                            .bodyValue(paymentRequest)
                            .retrieve()
                            .toBodilessEntity()
                            .retryWhen(
                                    Retry.backoff(2, Duration.ofMillis(100))
                                            .filter(ex ->
                                                    ex instanceof org.springframework.web.reactive.function.client.WebClientRequestException ||
                                                            (ex instanceof org.springframework.web.reactive.function.client.WebClientResponseException wcre && wcre.getStatusCode().is5xxServerError())
                                            )
                            )
                            .flatMap(response -> {
                                // Se sucesso (2xx), salva no Redis e retorna sucesso
                                if (response.getStatusCode().is2xxSuccessful()) {
                                    log.info("Pagamento processado com sucesso no gateway primário '{}' para correlationId={}, status={}", primary, paymentRequest.getCorrelationId(), response.getStatusCode());
                                    log.info("[RESULTADO] Pagamento processado no gateway: {}", primary);
                                    return valueOps.set(redisKeyPrimary, paymentRequest)
                                            .flatMap(saved -> {
                                                if (saved) {
                                                    return Mono.just(ResponseEntity.ok("Pagamento salvo com sucesso no Redis."));
                                                } else {
                                                    return Mono.just(ResponseEntity.status(500).body("Erro ao salvar no Redis."));
                                                }
                                            });
                                    // Se já existe (422), retorna 422 sem fallback e sem salvar no Redis
                                } else if (response.getStatusCode().value() == 422) {
                                    log.warn("Pagamento já existe no gateway primário '{}' para correlationId={}, status=422. Não será feito fallback e não será salvo no Redis.", primary, paymentRequest.getCorrelationId());
                                    return Mono.just(ResponseEntity.status(422).body("Pagamento já existe."));
                                    // Outros erros, lança exceção para acionar fallback
                                } else {
                                    log.error("Falha ao processar pagamento no gateway primário '{}' para correlationId={}, status={}", primary, paymentRequest.getCorrelationId(), response.getStatusCode());
                                    return Mono.error(new RuntimeException("Erro ao processar pagamento."));
                                }
                            });

                    // Envia requisição para o gateway secundário (fallback)
                    Mono<ResponseEntity<String>> trySecondary = webClient.post()
                            .uri(endpointSecondary)
                            .bodyValue(paymentRequest)
                            .retrieve()
                            .toBodilessEntity()
                            .flatMap(response -> {
                                // Se sucesso (2xx), salva no Redis e retorna sucesso
                                if (response.getStatusCode().is2xxSuccessful()) {
                                    log.info("Pagamento processado com sucesso no gateway secundário '{}' para correlationId={}, status={}", secondary, paymentRequest.getCorrelationId(), response.getStatusCode());
                                    log.info("[RESULTADO] Pagamento processado no gateway: {}", secondary);
                                    return valueOps.set(redisKeySecondary, paymentRequest)
                                            .flatMap(saved -> {
                                                if (saved) {
                                                    return Mono.just(ResponseEntity.ok("Pagamento salvo com sucesso no Redis."));
                                                } else {
                                                    return Mono.just(ResponseEntity.status(500).body("Erro ao salvar no Redis."));
                                                }
                                            });
                                    // Se já existe (422), retorna 422 sem salvar no Redis
                                } else if (response.getStatusCode().value() == 422) {
                                    log.warn("Pagamento j�� existe no gateway secundário '{}' para correlationId={}, status=422. Não será salvo no Redis.", secondary, paymentRequest.getCorrelationId());
                                    return Mono.just(ResponseEntity.status(422).body("Pagamento já existe."));
                                    // Outros erros, retorna erro genérico
                                } else {
                                    log.error("Falha ao processar pagamento no gateway secundário '{}' para correlationId={}, status={}", secondary, paymentRequest.getCorrelationId(), response.getStatusCode());
                                    return Mono.just(ResponseEntity.status(502).body("Erro ao processar pagamento no fallback."));
                                }
                            });

                    // Lógica de fallback e tratamento de respostas
                    return tryPrimary.flatMap(resp -> {
                        // Se status 422, não tenta fallback nem salva no Redis
                        if (resp.getStatusCode().value() == 422) {
                            return Mono.just(resp);
                            // Se sucesso, retorna
                        } else if (resp.getStatusCode().is2xxSuccessful()) {
                            return Mono.just(resp);
                            // Outros casos, tenta fallback
                        } else {
                            // Não deve chegar aqui, mas por segurança
                            return trySecondary.onErrorResume(e2 -> Mono.just(ResponseEntity.status(502).body("Erro ao processar pagamento em ambos os gateways.")));
                        }
                    }).onErrorResume(e -> {
                        // Se falhar no primário (exceto 422), tenta fallback
                        log.warn("Falha no gateway primário ('{}') para correlationId={}, tentando fallback. Erro: {}", primary, paymentRequest.getCorrelationId(), e.getMessage());
                        return trySecondary.flatMap(resp -> {
                            // Se status 422 no fallback, não salva no Redis nem tenta o primário
                            if (resp.getStatusCode().value() == 422) {
                                return Mono.just(resp);
                                // Se sucesso, retorna
                            } else if (resp.getStatusCode().is2xxSuccessful()) {
                                return Mono.just(resp);
                                // Outros casos, retorna erro genérico
                            } else {
                                return Mono.just(ResponseEntity.status(502).body("Erro ao processar pagamento em ambos os gateways."));
                            }
                        }).onErrorResume(e2 -> Mono.just(ResponseEntity.status(502).body("Erro ao processar pagamento em ambos os gateways.")));
                    });
                })
                .onErrorResume(e -> {
                    log.error("Erro inesperado ao processar pagamento para correlationId={}: {}", paymentRequest.getCorrelationId(), e.getMessage(), e);
                    return Mono.just(ResponseEntity.status(502).body("Erro ao processar pagamento."));
                });
    }


    @GetMapping("/payments-summary")
    public Mono<ResponseEntity<PaymentsSummaryResponse>> getPaymentSummary(
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to) {

        Mono<PaymentSummary> defaultSummary = summarizeGateway("default", from, to);
        Mono<PaymentSummary> fallbackSummary = summarizeGateway("fallback", from, to);

        return Mono.zip(defaultSummary, fallbackSummary)
                .map(tuple -> {
                    PaymentSummary defaultSum = tuple.getT1();
                    PaymentSummary fallbackSum = tuple.getT2();

                    var response = PaymentsSummaryResponse.builder()
                            ._default(defaultSum)
                            .fallback(fallbackSum)
                            .build();

                    return ResponseEntity.ok(response);
                });

    }

    private Mono<PaymentSummary> summarizeGateway(String gateway, String from, String to) {
        String pattern = "payment:" + gateway + ":*";
        return this.redisTemplate.scan(ScanOptions.scanOptions().match(pattern).build())
                .flatMap(valueOps::get)
                .filter(payment -> isWithinRange(payment, from, to))
                .collectList()
                .map(payments -> {
                    long totalRequests = payments.size();
                    double totalAmount = payments.stream()
                            .map(PaymentRequest::getAmount)
                            .mapToDouble(amount -> amount != null ? amount.doubleValue() : 0.0)
                            .sum();
                    return new PaymentSummary(totalRequests, totalAmount);
                });
    }

    private boolean isWithinRange(PaymentRequest payment, String from, String to) {
        if (payment == null || payment.getCreatedAt() == null) return false;

        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
        OffsetDateTime createdAt = OffsetDateTime.parse(payment.getCreatedAt().toString(), formatter);

        OffsetDateTime fromDate = from != null ? OffsetDateTime.parse(from, formatter) : OffsetDateTime.MIN;
        OffsetDateTime toDate = to != null ? OffsetDateTime.parse(to, formatter) : OffsetDateTime.MAX;

        return (createdAt.isEqual(fromDate) || createdAt.isAfter(fromDate))
                && (createdAt.isEqual(toDate) || createdAt.isBefore(toDate));
    }

    // Recupera o PaymentRequest do Redis pela chave
    @GetMapping("/payments/{gateway}/{correlationId}")
    public Mono<ResponseEntity<PaymentRequest>> getPayment(
            @PathVariable String gateway,
            @PathVariable String correlationId) {
        String redisKey = "payment:" + gateway + ":" + correlationId;
        log.info("Recuperando PaymentRequest do Redis com chave: {}", redisKey);
        return valueOps.get(redisKey)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    private Mono<String> selectBestGateway() {
        var stringValueOps = this.redisTemplateString.opsForValue();
        Mono<String> defaultHealth = stringValueOps.get("health:default");
        Mono<String> fallbackHealth = stringValueOps.get("health:fallback");

        return Mono.zip(defaultHealth, fallbackHealth)
                .flatMap(tuple -> {
                    class GatewayStatus {
                        String name;
                        boolean failing;
                        int minResponseTime;

                        GatewayStatus(String name, boolean failing, int minResponseTime) {
                            this.name = name;
                            this.failing = failing;
                            this.minResponseTime = minResponseTime;
                        }
                    }
                    GatewayStatus[] statuses = new GatewayStatus[2];
                    String[] names = {"default", "fallback"};
                    String[] jsons = {tuple.getT1(), tuple.getT2()};
                    for (int i = 0; i < 2; i++) {
                        String json = jsons[i];
                        if (json != null) {
                            boolean failing = json.contains("\"failing\":true");
                            int minResponseTime = Integer.parseInt(json.replaceAll(".*\"minResponseTime\":(\\d+).*", "$1"));
                            statuses[i] = new GatewayStatus(names[i], failing, minResponseTime);
                        } else {
                            statuses[i] = new GatewayStatus(names[i], true, Integer.MAX_VALUE);
                        }
                    }
                    List<GatewayStatus> healthy = List.of(statuses).stream()
                            .filter(s -> !s.failing)
                            .toList();
                    if (!healthy.isEmpty()) {
                        // Se há pelo menos um saudável, pega o de menor latência
                        return Mono.just(healthy.stream()
                                .min((a, b) -> Integer.compare(a.minResponseTime, b.minResponseTime))
                                .map(s -> s.name)
                                .orElse(null));
                    } else {
                        // Se todos estão falhando, pega o primeiro (para não perder pagamento)
                        return Mono.just(statuses[0].name);
                    }
                });
    }
}
