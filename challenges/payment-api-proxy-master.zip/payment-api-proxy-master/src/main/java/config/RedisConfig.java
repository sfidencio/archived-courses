package config;

import dto.PaymentRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.ReactiveRedisConnectionFactory;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
public class RedisConfig {
    @Bean
    public ReactiveRedisTemplate<String, PaymentRequest> reactiveRedisTemplate(ReactiveRedisConnectionFactory factory) {
        StringRedisSerializer keySerializer = new StringRedisSerializer();
        GenericJackson2JsonRedisSerializer valueSerializer = new GenericJackson2JsonRedisSerializer();
        RedisSerializationContext.SerializationPair<PaymentRequest> valuePair = (RedisSerializationContext.SerializationPair<PaymentRequest>) (RedisSerializationContext.SerializationPair<?>) RedisSerializationContext.SerializationPair.fromSerializer(valueSerializer);
        RedisSerializationContext<String, PaymentRequest> context = RedisSerializationContext
                .<String, PaymentRequest>newSerializationContext(keySerializer)
                .value(valuePair)
                .build();
        return new ReactiveRedisTemplate<>(factory, context);
    }


    // Template genérico para String (JSON ou texto)
    @Bean
    public ReactiveRedisTemplate<String, String> reactiveStringRedisTemplate(ReactiveRedisConnectionFactory factory) {
        StringRedisSerializer serializer = new StringRedisSerializer();
        RedisSerializationContext<String, String> context = RedisSerializationContext
                .<String, String>newSerializationContext(serializer)
                .value(serializer)
                .build();
        return new ReactiveRedisTemplate<>(factory, context);
    }
}