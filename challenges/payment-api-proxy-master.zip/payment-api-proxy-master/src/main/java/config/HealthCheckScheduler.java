package config;

import dto.HealthReponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
@Slf4j
@EnableScheduling
public class HealthCheckScheduler {
    private final WebClient webClient;
    private final ValueOperations<String, String> valueOps;


    public HealthCheckScheduler(WebClient.Builder webClientBuilder, RedisTemplate<String, String> redisTemplate) {
        this.webClient = webClientBuilder.build();
        this.valueOps = redisTemplate.opsForValue();
    }

    @Value("${processor.payment.default.url}")
    private String defaultUrl;

    @Value("${processor.payment.fallback.url}")
    private String fallbackUrl;

    @Value("${healthcheck.interval:20000}")
    private long healthCheckInterval;

    @Scheduled(fixedDelayString = "${healthcheck.interval:20000}")
    public void checkHealth() {
        checkAndSaveHealth(defaultUrl, "default");
        checkAndSaveHealth(fallbackUrl, "fallback");
    }

    private void checkAndSaveHealth(String url, String key) {
        log.info("Iniciando health check para {}...", url);
        webClient.get()
                .uri(url + "/service-health")
                .retrieve()
                .bodyToMono(HealthReponse.class)
                .doOnNext(response -> {
                    log.info("Health check bem-sucedido para {}: {}", key, response);
                    String json = String.format("{\"failing\":%s,\"minResponseTime\":%d}", response.isFailing(), response.getMinResponseTime());
                    valueOps.set("health:" + key, json);
                })
                .onErrorResume(e -> {
                    log.warn("Health check falhou para {}: {}", key, e.getMessage());
                    valueOps.set("health:" + key, "{\"failing\":true,\"minResponseTime\":0}");
                    return Mono.empty();
                })
                .subscribe();
    }
}
