package config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.time.Duration;

@Configuration
@Slf4j
public class WebClientConfig {

    @Value("${webclient.connect-timeout:3000}")
    private int connectTimeout;

    @Value("${webclient.pool-size:600}")
    private int poolSize;

    @Bean
    public WebClient.Builder webClientBuilder() {
        ConnectionProvider provider = ConnectionProvider.builder("custom")
                .maxConnections(poolSize)
                .build();

        log.info("WebClient connection pool size: {}", poolSize);
        log.info("WebClient connection timeout: {} ms", connectTimeout);

        HttpClient httpClient = HttpClient.create(provider)
                .option(io.netty.channel.ChannelOption.CONNECT_TIMEOUT_MILLIS, connectTimeout)
                .responseTimeout(Duration.ofMillis(connectTimeout));



        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient));
    }
}

