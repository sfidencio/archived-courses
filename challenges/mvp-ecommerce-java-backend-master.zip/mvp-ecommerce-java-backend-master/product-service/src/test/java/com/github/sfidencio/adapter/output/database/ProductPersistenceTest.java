package com.github.sfidencio.adapter.output.database;

import com.github.sfidencio.adapter.output.database.entities.ProductEntity;
import com.github.sfidencio.adapter.output.database.repository.IProductRespository;
import com.github.sfidencio.adapter.output.mappers.IProductInfraMapper;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductPersistenceTest {

    @Mock
    private IProductRespository respository;

    @InjectMocks
    private ProductPersistence productPersistence;

    private ProductEntity productEntity =
            ProductEntity.builder()
                    .id(UUID.randomUUID().toString())
                    .description("Product description")
                    .price(BigDecimal.TEN)
                    .stock(BigDecimal.ONE)
                    .build();

    @BeforeEach
    void setUp() {
        this.productPersistence = new ProductPersistence(respository, Mappers.getMapper(IProductInfraMapper.class));
    }

    @Test
    @DisplayName("""
                Dado que o produto seja salvo com sucesso
                Quando o método execute for chamado
                Então deve retornar o produto salvo
            """)
    void givenProductSavedSuccessfullyWhenExecuteIsCalledThenReturnProductSaved() {
        when(respository.save(any())).thenReturn(this.productEntity);

        var product = this.productPersistence.execute(Mappers.getMapper(IProductInfraMapper.class).toDomain(this.productEntity));

        Assertions.assertThat(product).isNotNull();
    }
}