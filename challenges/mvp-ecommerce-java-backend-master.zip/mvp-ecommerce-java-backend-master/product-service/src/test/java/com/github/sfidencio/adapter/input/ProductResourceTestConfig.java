package com.github.sfidencio.adapter.input;

import com.github.sfidencio.application.mappers.IProductApplicationMapper;
import com.github.sfidencio.config.ObjectMapperConfig;
import com.github.sfidencio.ports.input.ICreateCreateProductUseCaseInput;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

import static org.mockito.Mockito.mock;

@TestConfiguration
@Import(ObjectMapperConfig.class)
public class ProductResourceTestConfig {
    @Bean
    public ICreateCreateProductUseCaseInput createProductUseCaseInput() {
        return mock(ICreateCreateProductUseCaseInput.class);
    }

    @Bean
    public IProductApplicationMapper productApplicationMapper() {
        return mock(IProductApplicationMapper.class);
    }
}
