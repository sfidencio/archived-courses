package com.github.sfidencio.adapter.input;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.sfidencio.application.mappers.IProductApplicationMapper;
import com.github.sfidencio.ports.input.ICreateCreateProductUseCaseInput;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ProductResource.class)
@Import(ProductResourceTestConfig.class)
class ProductResourceTest implements ITestFixtures {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private ICreateCreateProductUseCaseInput createProductUseCase;

    @Autowired
    private IProductApplicationMapper productApplicationMapper;

    @Test
    @DisplayName("""
            Dado que estou tentando criar um produto
            Quando o método POST for chamado
            Então deve retornar o produto criado
            """)
    void givenProductSavedSuccessfullyWhenPostIsCalledThenReturnProductSaved() throws Exception {
        //given
        var categoryID = createRandomCategoryId();
        var request = createProductRequest();
        var product = createProduct();
        var response = createProductResponse(product);

        //when
        given(this.productApplicationMapper.toDomain(request)).willReturn(product);
        given(this.createProductUseCase.execute(any(), any())).willReturn(product);
        given(this.productApplicationMapper.toResponse(product)).willReturn(response);


        //then
        this.mockMvc.perform(
                        post("/v1/categories/{id}/products", categoryID)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(objectMapper.writeValueAsString(request)))
                .andDo(print())
                .andExpect(status().isCreated());
    }
}