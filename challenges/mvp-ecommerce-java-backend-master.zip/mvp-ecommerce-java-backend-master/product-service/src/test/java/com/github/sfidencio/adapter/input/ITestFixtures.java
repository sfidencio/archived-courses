package com.github.sfidencio.adapter.input;

import com.github.sfidencio.application.dto.CreateProductRequest;
import com.github.sfidencio.application.dto.CreateProductResponse;
import com.github.sfidencio.domain.entities.Product;

import java.math.BigDecimal;
import java.util.UUID;

public interface ITestFixtures {
    default CreateProductRequest createProductRequest() {
        return CreateProductRequest.builder()
                .sku("123456")
                .description("iPhone 15 Pro Max")
                .price(new BigDecimal("999.99"))
                .stock(new BigDecimal("10"))
                .build();
    }

    default Product createProduct() {
        return Product.builder()
                .id(UUID.randomUUID())
                .description("iPhone 15 Pro Max")
                .price(new BigDecimal("999.99"))
                .stock(new BigDecimal("10"))
                .build();
    }

    default CreateProductResponse createProductResponse(Product product) {
        return CreateProductResponse.builder()
                .id(product.id())
                .description(product.description())
                .price(product.price())
                .stock(product.stock())
                .build();
    }

    default UUID createRandomCategoryId() {
        return UUID.randomUUID();
    }
}
