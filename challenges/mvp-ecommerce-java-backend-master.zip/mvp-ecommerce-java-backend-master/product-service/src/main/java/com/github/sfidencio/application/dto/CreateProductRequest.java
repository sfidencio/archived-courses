package com.github.sfidencio.application.dto;

import lombok.Builder;

import java.math.BigDecimal;
import java.util.UUID;

@Builder
public record CreateProductRequest(
                                   String sku,
                                   UUID categoryId,
                                   String description,
                                   BigDecimal price,
                                   BigDecimal stock) {
}
