package com.github.sfidencio.adapter.input;

import com.github.sfidencio.application.dto.CreateProductRequest;
import com.github.sfidencio.application.dto.CreateProductResponse;
import com.github.sfidencio.application.mappers.IProductApplicationMapper;
import com.github.sfidencio.config.Constants;
import com.github.sfidencio.ports.input.ICreateCreateProductUseCaseInput;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping(Constants.ENDPOINT_CATEGORIES + "/{" + Constants.CATEGORY_ID + "}" + Constants.ENDPOINT_PRODUCTS)
public class ProductResource implements IProductResource {
    private final ICreateCreateProductUseCaseInput createProductUseCase;
    private final IProductApplicationMapper mapper;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Override
    public CreateProductResponse createProduct(@PathVariable(Constants.CATEGORY_ID) UUID id,
                                               @RequestBody CreateProductRequest request) {
        var productDomain = this.createProductUseCase.execute(id, this.mapper.toDomain(request));
        return this.mapper.toResponse(productDomain);
    }
}
