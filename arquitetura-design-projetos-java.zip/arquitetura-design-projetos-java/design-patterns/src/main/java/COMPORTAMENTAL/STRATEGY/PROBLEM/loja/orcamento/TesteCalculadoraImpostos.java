package COMPORTAMENTAL.STRATEGY.PROBLEM.loja.orcamento;

import java.math.BigDecimal;

public class TesteCalculadoraImpostos {
    public static void main(String[] args) {
        Orcamento orcamento = new Orcamento(new BigDecimal("400.00"));
        CalculadoraDeImpostos calculadoraDeImpostos = new CalculadoraDeImpostos();
        System.out.println("Valor do Orcamento: " + orcamento.getValor());
        BigDecimal resultadoICMS = calculadoraDeImpostos.calcular(orcamento,TipoImposto.ICMS);
        System.out.println("Calculo ICMS: " + resultadoICMS);
        BigDecimal resultadoISS = calculadoraDeImpostos.calcular(orcamento,TipoImposto.ISS);
        System.out.println("Calculo ISS: " + resultadoISS);

    }
}
