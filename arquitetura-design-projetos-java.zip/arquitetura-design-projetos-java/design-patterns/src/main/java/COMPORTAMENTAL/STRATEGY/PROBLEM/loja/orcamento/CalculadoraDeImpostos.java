package COMPORTAMENTAL.STRATEGY.PROBLEM.loja.orcamento;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class CalculadoraDeImpostos {
    public BigDecimal calcular(Orcamento orcamento, TipoImposto tipoImposto) {
        //Sempre que houver a necessidade de calcular o imposto novo em cima do orcamento,
        //teremos que incluir neste switch
        //Paradigma estruturado
        //Regra varia de acordo com parametro TipoImposto
        //Cada calculo tera sua "estrategia" de calculo
        switch (tipoImposto) {
            case ISS:
                return orcamento.getValor().multiply(new BigDecimal("0.06")).setScale(2, RoundingMode.HALF_UP);
            //break;
            case ICMS:
                return orcamento.getValor().multiply(new BigDecimal("0.10")).setScale(2, RoundingMode.HALF_UP);
            case PIS:
                return orcamento.getValor().multiply(new BigDecimal("0.07")).setScale(2, RoundingMode.HALF_UP);
            //break;
            default:
                return BigDecimal.ZERO;
        }
    }
}
