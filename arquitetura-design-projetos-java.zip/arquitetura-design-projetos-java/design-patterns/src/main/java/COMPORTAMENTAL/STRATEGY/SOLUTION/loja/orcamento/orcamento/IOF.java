package COMPORTAMENTAL.STRATEGY.SOLUTION.loja.orcamento.orcamento;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class IOF implements Imposto {
    @Override
    public BigDecimal calcular(Orcamento orcamento) {
        return orcamento.getValor().multiply(new BigDecimal("0.009")).setScale(2, RoundingMode.HALF_UP);
    }
}
