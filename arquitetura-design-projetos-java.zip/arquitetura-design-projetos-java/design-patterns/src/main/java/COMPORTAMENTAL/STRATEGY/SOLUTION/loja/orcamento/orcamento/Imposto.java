package COMPORTAMENTAL.STRATEGY.SOLUTION.loja.orcamento.orcamento;

import java.math.BigDecimal;

public interface Imposto {
    BigDecimal calcular(Orcamento orcamento);
}
