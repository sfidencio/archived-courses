package COMPORTAMENTAL.STRATEGY.PROBLEM.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS,PIS
}
