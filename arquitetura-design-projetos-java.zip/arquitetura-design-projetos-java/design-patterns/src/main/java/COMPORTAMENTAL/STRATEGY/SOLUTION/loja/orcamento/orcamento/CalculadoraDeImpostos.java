package COMPORTAMENTAL.STRATEGY.SOLUTION.loja.orcamento.orcamento;

import java.math.BigDecimal;

public class CalculadoraDeImpostos {
    //Aqui usamos o pattern Strategy, onde utilizamos interface para desacoplar o codigo
    //Deixando mais coeso, de modo que se precisar acrescentar mais regras..
    //Baseada em um novo imposto, so criar uma nova classe e implementar o contrato (Imposto)
    public BigDecimal calcular(Orcamento orcamento, Imposto imposto) {
        return imposto.calcular(orcamento);
    }
}
