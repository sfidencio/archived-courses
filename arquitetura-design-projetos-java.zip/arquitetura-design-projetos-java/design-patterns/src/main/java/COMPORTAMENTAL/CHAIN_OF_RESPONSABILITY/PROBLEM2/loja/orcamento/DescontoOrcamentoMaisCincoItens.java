package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.PROBLEM2.loja.orcamento;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class DescontoOrcamentoMaisCincoItens {
    public BigDecimal calcular(Orcamento orcamento) {
        if (orcamento.getQtdItens() > 5)
            return orcamento.getValor().multiply(new BigDecimal("0.1")).setScale(2, RoundingMode.HALF_UP);
        return BigDecimal.ZERO;
    }
}
