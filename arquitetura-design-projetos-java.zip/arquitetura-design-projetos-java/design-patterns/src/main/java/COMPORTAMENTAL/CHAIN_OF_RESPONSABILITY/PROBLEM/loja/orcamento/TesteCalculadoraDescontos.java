package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.PROBLEM.loja.orcamento;

import java.math.BigDecimal;

public class TesteCalculadoraDescontos {

    public static void main(String[] args) {


        Orcamento orcamento1 = new Orcamento(new BigDecimal("400.00"),4);
        CalculadoraDeDescontos calculadoraDeDescontos1 = new CalculadoraDeDescontos();
        BigDecimal calculoOrcamento1 = calculadoraDeDescontos1.calcular(orcamento1);
        System.out.println(calculoOrcamento1);



        Orcamento orcamento2 = new Orcamento(new BigDecimal("550.00"),4);
        CalculadoraDeDescontos calculadoraDeDescontos2 = new CalculadoraDeDescontos();
        BigDecimal calculoOrcamento2 = calculadoraDeDescontos2.calcular(orcamento2);
        System.out.println(calculoOrcamento2);




        Orcamento orcamento3 = new Orcamento(new BigDecimal("250.00"),6);
        CalculadoraDeDescontos calculadoraDeDescontos3 = new CalculadoraDeDescontos();
        BigDecimal calculoOrcamento3 = calculadoraDeDescontos3.calcular(orcamento3);
        System.out.println(calculoOrcamento3);



        //Este cenario nao tem como ser executado ambas as regras, pois return ocorre na primeira
        //na calculadora de descontos..teria que acumular os descontos como fazer isso?
        Orcamento orcamento4 = new Orcamento(new BigDecimal("700.00"),6);
        CalculadoraDeDescontos calculadoraDeDescontos4 = new CalculadoraDeDescontos();
        BigDecimal calculoOrcamento4 = calculadoraDeDescontos4.calcular(orcamento4);
        System.out.println(calculoOrcamento4);


    }
}
