package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.SOLUTION.loja.orcamento;


import java.math.BigDecimal;

public class CalculadoraDeDescontos {
    //Observem que este problema nao tem como ser resolvido com pattern Strategy,
    //Dado que se o orcamento cair no primeiro if/cenario, ele ja ira retorna o desconto
    //Sem analisar se o segundo cenario tambem se encaixaria ou nao..na regra
    //Aqui precisamos acumular condições

    //Aqui aplicamos o patter ChainOfResponsability ou Cadeia de responsabilidade
    //Usamos aqui Herança de classes ao inves de interface

    //https://refactoring.guru/design-patterns/chain-of-responsibility
    public BigDecimal calcular(Orcamento orcamento) {
      Desconto desconto = new DescontoOrcamentoValorMaiorQuinhentos(new DescontoOrcamentoMaisCincoItens(new SemDesconto()));
      return desconto.calcular(orcamento);
    }
}
