package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.PROBLEM.loja.orcamento;


import java.math.BigDecimal;
import java.math.RoundingMode;

public class CalculadoraDeDescontos {
    //Observem que este problema nao tem como ser resolvido com pattern Strategy,
    //Dado que se o orcamento cair no primeiro if/cenario, ele ja ira retorna o desconto
    //Sem analisar se o segundo cenario tambem se encaixaria ou nao..na regra

    //Aqui precisamos acumular condições
    public BigDecimal calcular(Orcamento orcamento) {
        if (orcamento.getQtdItens() > 5)
            return orcamento.getValor().multiply(new BigDecimal("0.1")).setScale(2, RoundingMode.HALF_UP);
        if (orcamento.getValor().compareTo(new BigDecimal("500.00")) > 0)
            return orcamento.getValor().multiply(new BigDecimal("0.2")).setScale(2, RoundingMode.HALF_UP);
        return BigDecimal.ZERO;
    }
}
