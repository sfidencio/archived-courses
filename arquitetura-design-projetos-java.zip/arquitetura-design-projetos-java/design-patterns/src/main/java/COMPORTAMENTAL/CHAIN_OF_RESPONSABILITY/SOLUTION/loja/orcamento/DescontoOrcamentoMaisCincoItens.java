package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.SOLUTION.loja.orcamento;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class DescontoOrcamentoMaisCincoItens extends Desconto {
    public DescontoOrcamentoMaisCincoItens(Desconto proximo) {
        super(proximo);
    }

    public BigDecimal calcular(Orcamento orcamento) {
        if (orcamento.getQtdItens() > 5)
            return orcamento.getValor().multiply(new BigDecimal("0.1")).setScale(2, RoundingMode.HALF_UP);
        return proximo.calcular(orcamento);
    }
}
