package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.PROBLEM.loja.orcamento;

import java.math.BigDecimal;

public class CalculadoraDeImpostos {
    public BigDecimal calcular(Orcamento orcamento, Imposto imposto) {
        return imposto.calcular(orcamento);
    }
}
