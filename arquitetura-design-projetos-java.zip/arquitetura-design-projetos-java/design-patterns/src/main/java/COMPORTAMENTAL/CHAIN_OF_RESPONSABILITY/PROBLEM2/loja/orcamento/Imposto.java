package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.PROBLEM2.loja.orcamento;

import java.math.BigDecimal;

public interface Imposto {
    BigDecimal calcular(Orcamento orcamento);
}
