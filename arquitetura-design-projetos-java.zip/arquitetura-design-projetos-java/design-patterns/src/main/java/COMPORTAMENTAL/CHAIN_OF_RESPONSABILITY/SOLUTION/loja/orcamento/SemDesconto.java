package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.SOLUTION.loja.orcamento;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class SemDesconto extends Desconto {
    public SemDesconto() {
        super(null);
    }

    public BigDecimal calcular(Orcamento orcamento) {
        return BigDecimal.ZERO;
    }
}
