package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.PROBLEM.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
