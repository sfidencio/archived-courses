package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.SOLUTION.loja.orcamento;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class DescontoOrcamentoValorMaiorQuinhentos extends Desconto {
    public DescontoOrcamentoValorMaiorQuinhentos(Desconto proximo) {
        super(proximo);
    }

    public BigDecimal calcular(Orcamento orcamento) {
        if (orcamento.getValor().compareTo(new BigDecimal("500.00")) > 0)
            return orcamento.getValor().multiply(new BigDecimal("0.2")).setScale(2, RoundingMode.HALF_UP);
        return proximo.calcular(orcamento);
    }
}
