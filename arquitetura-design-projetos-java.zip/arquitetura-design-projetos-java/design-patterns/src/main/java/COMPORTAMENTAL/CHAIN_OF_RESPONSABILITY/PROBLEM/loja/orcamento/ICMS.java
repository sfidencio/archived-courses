package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.PROBLEM.loja.orcamento;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class ICMS implements Imposto {
    @Override
    public BigDecimal calcular(Orcamento orcamento) {
        return orcamento.getValor().multiply(new BigDecimal("0.1")).setScale(2, RoundingMode.HALF_UP);
    }
}
