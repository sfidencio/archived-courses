package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.SOLUTION.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
