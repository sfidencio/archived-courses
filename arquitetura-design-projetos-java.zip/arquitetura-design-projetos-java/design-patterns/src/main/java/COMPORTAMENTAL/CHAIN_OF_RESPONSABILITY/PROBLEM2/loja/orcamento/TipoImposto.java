package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.PROBLEM2.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
