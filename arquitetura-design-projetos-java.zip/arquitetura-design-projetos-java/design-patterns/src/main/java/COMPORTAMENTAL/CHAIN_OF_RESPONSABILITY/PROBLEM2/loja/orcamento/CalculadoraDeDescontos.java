package COMPORTAMENTAL.CHAIN_OF_RESPONSABILITY.PROBLEM2.loja.orcamento;


import java.math.BigDecimal;

public class CalculadoraDeDescontos {
    //Observem que este problema nao tem como ser resolvido com pattern Strategy,
    //Dado que se o orcamento cair no primeiro if/cenario, ele ja ira retorna o desconto
    //Sem analisar se o segundo cenario tambem se encaixaria ou nao..na regra
    //Aqui precisamos acumular condições
    public BigDecimal calcular(Orcamento orcamento) {
        BigDecimal descontoCalcular = new DescontoOrcamentoMaisCincoItens().calcular(orcamento);
        if(descontoCalcular == BigDecimal.ZERO){
            descontoCalcular = new DescontoOrcamentoValorMaiorQuinhentos().calcular(orcamento);
        }
        return descontoCalcular;
    }
}
