package COMPORTAMENTAL.TEMPLATE_METHOD.PROBLEM.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
