package COMPORTAMENTAL.TEMPLATE_METHOD.PROBLEM.loja.orcamento;

import java.math.BigDecimal;

public class TesteCalculadoraImpostos {
    public static void main(String[] args) {
        Orcamento orcamento = new Orcamento(new BigDecimal("400.00"));
        CalculadoraDeImpostos calculadoraDeImpostos = new CalculadoraDeImpostos();

        BigDecimal resultadoICMS = calculadoraDeImpostos.calcular(orcamento, new ICMS());
        System.out.println("Calculo ICMS: " + resultadoICMS);

        BigDecimal resultadoISS = calculadoraDeImpostos.calcular(orcamento, new ISS());
        System.out.println("Calculo ISS: " + resultadoISS);

        BigDecimal resultadoPIS = calculadoraDeImpostos.calcular(orcamento, new PIS());
        System.out.println("Calculo PIS: " + resultadoPIS);

    }
}
