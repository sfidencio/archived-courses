package COMPORTAMENTAL.TEMPLATE_METHOD.SOLUTION.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
