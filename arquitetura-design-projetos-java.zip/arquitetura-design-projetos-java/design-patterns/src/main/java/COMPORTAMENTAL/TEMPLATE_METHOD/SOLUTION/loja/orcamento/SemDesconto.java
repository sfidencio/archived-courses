package COMPORTAMENTAL.TEMPLATE_METHOD.SOLUTION.loja.orcamento;

import COMPORTAMENTAL.TEMPLATE_METHOD.SOLUTION.loja.orcamento.descontos.Desconto;

import java.math.BigDecimal;

public class SemDesconto extends Desconto {
    public SemDesconto() {
        super(null);
    }

    public BigDecimal efetuarCalculo(Orcamento orcamento) {
        return BigDecimal.ZERO;
    }

    @Override
    protected Boolean deveAplicar(Orcamento orcamento) {
        return true;
    }
}
