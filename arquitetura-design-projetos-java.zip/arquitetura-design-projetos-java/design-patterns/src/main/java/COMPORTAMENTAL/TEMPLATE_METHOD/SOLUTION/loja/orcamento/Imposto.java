package COMPORTAMENTAL.TEMPLATE_METHOD.SOLUTION.loja.orcamento;

import java.math.BigDecimal;

public interface Imposto {
    BigDecimal calcular(Orcamento orcamento);
}
