package COMPORTAMENTAL.TEMPLATE_METHOD.PROBLEM.loja.orcamento;

import java.math.BigDecimal;

public interface Imposto {
    BigDecimal calcular(Orcamento orcamento);
}
