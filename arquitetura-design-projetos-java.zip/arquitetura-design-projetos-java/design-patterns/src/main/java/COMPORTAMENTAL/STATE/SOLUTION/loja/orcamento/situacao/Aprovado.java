package COMPORTAMENTAL.STATE.SOLUTION.loja.orcamento.situacao;

import COMPORTAMENTAL.STATE.SOLUTION.loja.orcamento.Orcamento;
import COMPORTAMENTAL.STATE.SOLUTION.loja.orcamento.exceptions.DomainException;

import java.math.BigDecimal;

public class Aprovado extends SituacaoOrcamento {
    @Override
    public BigDecimal calcularValorDescontoExtra(Orcamento orcamento) {
        return orcamento.getValor().multiply(new BigDecimal("0.02"));
    }

    @Override
    public void finalizar(Orcamento orcamento) {
        orcamento.setSituacao(new Finalizado());
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
