package COMPORTAMENTAL.STATE.PROBLEM.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
