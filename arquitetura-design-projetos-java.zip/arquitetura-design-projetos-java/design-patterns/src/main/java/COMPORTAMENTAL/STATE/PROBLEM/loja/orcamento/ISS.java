package COMPORTAMENTAL.STATE.PROBLEM.loja.orcamento;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class ISS implements Imposto {
    @Override
    public BigDecimal calcular(Orcamento orcamento) {
        return orcamento.getValor().multiply(new BigDecimal("0.06")).setScale(2, RoundingMode.HALF_UP);
    }
}
