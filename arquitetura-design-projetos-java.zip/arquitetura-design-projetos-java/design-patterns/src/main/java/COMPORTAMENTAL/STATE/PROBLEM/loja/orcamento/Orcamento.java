package COMPORTAMENTAL.STATE.PROBLEM.loja.orcamento;

import java.math.BigDecimal;

public class Orcamento {
    private BigDecimal valor;
    private int qtdItens;

    private String situacaoOrcamento; //EM_ANALISE, APROVADO, REPROVADO, FINALIZADO

    public Orcamento(BigDecimal valor) {
        this.valor = valor;
    }

    public Orcamento(BigDecimal valor, int qtdItens) {
        this.valor = valor;
        this.qtdItens = qtdItens;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public int getQtdItens() {
        return qtdItens;
    }

    /*
     *Nao e um jeito inteligente de transitar os estados do objeto
     * Seria interessante utilizar ENUM..uma estrategia diferente
     * com uso de herança e aplicacao do pattern STATE
     */
    public void aplicarDescontoExtra(){
        BigDecimal valorDescontoExtra = BigDecimal.ZERO;
        if(situacaoOrcamento.equals("EM_ANALISE"))
            valorDescontoExtra = new BigDecimal("0.05");
        else if(situacaoOrcamento.equals("APROVADO"))
            valorDescontoExtra = new BigDecimal("0.02");
        this.valor = this.valor.subtract(valorDescontoExtra);
    }

    //Transicao de estados..
    public void aprovar(){
        this.situacaoOrcamento = "APROVADO";
    }
}


