package COMPORTAMENTAL.STATE.SOLUTION.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
