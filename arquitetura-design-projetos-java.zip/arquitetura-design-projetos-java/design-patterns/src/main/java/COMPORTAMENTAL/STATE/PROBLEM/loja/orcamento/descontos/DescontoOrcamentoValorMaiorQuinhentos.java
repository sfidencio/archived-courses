package COMPORTAMENTAL.STATE.PROBLEM.loja.orcamento.descontos;

import COMPORTAMENTAL.STATE.PROBLEM.loja.orcamento.Orcamento;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class DescontoOrcamentoValorMaiorQuinhentos extends Desconto {
    public DescontoOrcamentoValorMaiorQuinhentos(Desconto proximo) {
        super(proximo);
    }

    public BigDecimal efetuarCalculo(Orcamento orcamento) {
        return orcamento.getValor().multiply(new BigDecimal("0.2")).setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    protected Boolean deveAplicar(Orcamento orcamento) {
        return orcamento.getValor().compareTo(new BigDecimal("500.00"))>0;
    }
}
