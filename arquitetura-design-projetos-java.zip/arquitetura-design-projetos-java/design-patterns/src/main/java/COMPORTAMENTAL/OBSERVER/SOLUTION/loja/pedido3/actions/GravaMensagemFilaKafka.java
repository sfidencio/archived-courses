package COMPORTAMENTAL.OBSERVER.SOLUTION.loja.pedido3.actions;

import COMPORTAMENTAL.OBSERVER.SOLUTION.loja.pedido3.AcaoAposGerarPedido;
import COMPORTAMENTAL.OBSERVER.SOLUTION.loja.pedido3.Pedido;

public class GravaMensagemFilaKafka implements AcaoAposGerarPedido {
    @Override
    public void executar(Pedido pedido) {
        System.out.println("Salvar topico do KAFKA ->" + pedido);
    }

}
