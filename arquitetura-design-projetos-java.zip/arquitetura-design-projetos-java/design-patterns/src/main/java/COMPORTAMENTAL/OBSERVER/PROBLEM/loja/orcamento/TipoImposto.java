package COMPORTAMENTAL.OBSERVER.PROBLEM.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
