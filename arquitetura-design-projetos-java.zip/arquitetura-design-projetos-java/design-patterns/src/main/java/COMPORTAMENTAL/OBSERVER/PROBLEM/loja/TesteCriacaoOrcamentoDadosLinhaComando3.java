package COMPORTAMENTAL.OBSERVER.PROBLEM.loja;
import COMPORTAMENTAL.OBSERVER.PROBLEM.loja.pedido3.GeraPedido;
import COMPORTAMENTAL.OBSERVER.PROBLEM.loja.pedido3.GeraPedidoHandler;

import java.math.BigDecimal;

public class TesteCriacaoOrcamentoDadosLinhaComando3 {

    public static void main(String[] args) {
        //Gerando pedido  - aplicando o pattern command dados linha comando
        //Observe que delegamos a geracao do pedido para classe GeraPedidoFacade
        GeraPedido geraPedido = new GeraPedido("CLIENTE 3",new BigDecimal("400.20"),4);
        GeraPedidoHandler handler = new GeraPedidoHandler(/*dependencias ->@services, @repository*/);
        handler.executar(geraPedido);
        System.out.println(geraPedido.getPedido());
    }
}
