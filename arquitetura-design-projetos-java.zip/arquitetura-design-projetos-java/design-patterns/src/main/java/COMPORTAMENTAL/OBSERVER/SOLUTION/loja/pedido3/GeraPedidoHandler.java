package COMPORTAMENTAL.OBSERVER.SOLUTION.loja.pedido3;

import COMPORTAMENTAL.OBSERVER.SOLUTION.loja.orcamento.Orcamento;
import COMPORTAMENTAL.OBSERVER.SOLUTION.loja.pedido3.actions.GeraPedido;

import java.time.LocalDateTime;
import java.util.List;

//Handler manipula os comandos..variacao do commands
//separa dados da logica de execucao dos comandos
//OS PURISTAS da OO nao gostam de separar os dados dos comportamentos.

/*O padrão de projetos Command é, provavelmente,
  um dos que mais gera confusão, principalmente no mundo de desenvolvimento web em geral,
  já que alguns conceitos mais específicos pro mundo da web surgiram
  e são diferentes dos existentes em aplicações desktop.
  Para você entender melhor sobre o padrão Command "original" (definido no livro da GoF),
  você pode dar uma olhada nesse link: https://refactoring.guru/design-patterns/command.
  Também é muito interessante o estudo de alguns padrões de arquitetura de software,
  como Domain Driven Design e Clean Architecture,
  pois você vai esbarrar no padrão de Command Handlers
  (que foi aplicado de forma bem simples nesta aula).
  */

/*
 *Um Command Handler tem como responsabilidade,
 *normalmente,
 *apenas orquestrar as tarefas a serem executadas, ou seja,
 * chamar as classes necessárias que realizam as tarefas desejadas.
 * No nosso caso,
 * o Command Handler tinha todo o código do fluxo em seu corpo.
 *
 * //Se torna mais coesos separar o commands em classes distintas...
 */

public class GeraPedidoHandler {

    /*utiilzar inversao de contrrle ou injecao de dependencias para injetar uma
     * lista de acoes, implementados pelo padrao Observer
     * usando inteface pra abstracao as acoes ou objetos dependentes desta classe*/

    private List<AcaoAposGerarPedido> acoes;

    public GeraPedidoHandler(List<AcaoAposGerarPedido> acoes) {
        this.acoes = acoes;
    }

    public void executar(GeraPedido dados) {
        Orcamento orcamento = new Orcamento(dados.getValorOrcamento(), dados.getQtdeItens());
        dados.setPedido(new Pedido(dados.getCliente(), LocalDateTime.now(), orcamento));

        //Executa acoes registradas como evento ou observer..
        this.acoes.forEach(acao->acao.executar(dados.getPedido()));

    }
}
