package COMPORTAMENTAL.OBSERVER.SOLUTION.loja.pedido2;

import COMPORTAMENTAL.OBSERVER.SOLUTION.loja.orcamento.Orcamento;

import java.time.LocalDateTime;

//Handler manipula os comandos..variacao do commands
//separa dados da logica de execucao dos comandos
//OS PURISTAS da OO nao gostam de separar os dados dos comportamentos.

/*O padrão de projetos Command é, provavelmente,
  um dos que mais gera confusão, principalmente no mundo de desenvolvimento web em geral,
  já que alguns conceitos mais específicos pro mundo da web surgiram
  e são diferentes dos existentes em aplicações desktop.
  Para você entender melhor sobre o padrão Command "original" (definido no livro da GoF),
  você pode dar uma olhada nesse link: https://refactoring.guru/design-patterns/command.
  Também é muito interessante o estudo de alguns padrões de arquitetura de software,
  como Domain Driven Design e Clean Architecture,
  pois você vai esbarrar no padrão de Command Handlers
  (que foi aplicado de forma bem simples nesta aula).
  */
public class GeraPedidoHandler {


    public void executar(GeraPedido dados) {
        Orcamento orcamento = new Orcamento(dados.getValorOrcamento(), dados.getQtdeItens());
        dados.setPedido(new Pedido(dados.getCliente(), LocalDateTime.now(), orcamento));
    }
}
