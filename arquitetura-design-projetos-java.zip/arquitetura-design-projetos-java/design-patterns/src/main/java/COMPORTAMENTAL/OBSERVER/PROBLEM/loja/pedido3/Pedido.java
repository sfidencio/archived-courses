package COMPORTAMENTAL.OBSERVER.PROBLEM.loja.pedido3;

import COMPORTAMENTAL.OBSERVER.PROBLEM.loja.orcamento.Orcamento;

import java.time.LocalDateTime;

public class Pedido {
    private String cliente;
    private LocalDateTime dataHora;
    private Orcamento orcamento;

    public Pedido(String cliente, LocalDateTime dataHora, Orcamento orcamento) {
        this.cliente = cliente;
        this.dataHora = dataHora;
        this.orcamento = orcamento;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public Orcamento getOrcamento() {
        return orcamento;
    }

    public void setOrcamento(Orcamento orcamento) {
        this.orcamento = orcamento;
    }

    @Override
    public String toString() {
        return "Pedido{" +
                "cliente='" + cliente + '\'' +
                ", dataHora=" + dataHora +
                ", orcamento=" + orcamento +
                '}';
    }
}
