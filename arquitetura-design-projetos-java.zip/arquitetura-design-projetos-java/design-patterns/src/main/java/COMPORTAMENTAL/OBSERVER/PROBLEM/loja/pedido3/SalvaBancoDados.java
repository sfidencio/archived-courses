package COMPORTAMENTAL.OBSERVER.PROBLEM.loja.pedido3;

public class SalvaBancoDados {
    public void executar(Pedido pedido) {
        System.out.println("Salvar pedido banco de dados ->" + pedido);
    }
}
