package COMPORTAMENTAL.OBSERVER.SOLUTION.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
