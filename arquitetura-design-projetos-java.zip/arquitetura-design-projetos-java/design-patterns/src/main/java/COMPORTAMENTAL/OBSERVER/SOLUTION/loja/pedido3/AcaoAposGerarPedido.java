package COMPORTAMENTAL.OBSERVER.SOLUTION.loja.pedido3;

public interface AcaoAposGerarPedido {
    void executar(Pedido pedido);
}
