package COMPORTAMENTAL.OBSERVER.PROBLEM.loja.pedido3;

public class EnviaEmail {
    public void executar(Pedido pedido) {
        System.out.println("Email enviado para pedido ->" + pedido);
    }
}
