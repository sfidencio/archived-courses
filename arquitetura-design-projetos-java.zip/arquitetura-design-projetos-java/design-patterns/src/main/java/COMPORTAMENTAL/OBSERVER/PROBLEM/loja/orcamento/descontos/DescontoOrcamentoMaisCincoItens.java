package COMPORTAMENTAL.OBSERVER.PROBLEM.loja.orcamento.descontos;

import COMPORTAMENTAL.OBSERVER.PROBLEM.loja.orcamento.Orcamento;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class DescontoOrcamentoMaisCincoItens extends Desconto {
    public DescontoOrcamentoMaisCincoItens(Desconto proximo) {
        super(proximo);
    }

    public BigDecimal efetuarCalculo(Orcamento orcamento) {
        return orcamento.getValor().multiply(new BigDecimal("0.1")).setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    protected Boolean deveAplicar(Orcamento orcamento) {
        return orcamento.getQtdItens() > 5;
    }
}
