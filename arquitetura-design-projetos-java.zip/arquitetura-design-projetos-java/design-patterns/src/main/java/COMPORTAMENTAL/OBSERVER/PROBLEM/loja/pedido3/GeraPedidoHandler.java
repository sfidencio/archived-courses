package COMPORTAMENTAL.OBSERVER.PROBLEM.loja.pedido3;

import COMPORTAMENTAL.OBSERVER.PROBLEM.loja.orcamento.Orcamento;

import java.time.LocalDateTime;

//Handler manipula os comandos..variacao do commands
//separa dados da logica de execucao dos comandos
//OS PURISTAS da OO nao gostam de separar os dados dos comportamentos.

/*O padrão de projetos Command é, provavelmente,
  um dos que mais gera confusão, principalmente no mundo de desenvolvimento web em geral,
  já que alguns conceitos mais específicos pro mundo da web surgiram
  e são diferentes dos existentes em aplicações desktop.
  Para você entender melhor sobre o padrão Command "original" (definido no livro da GoF),
  você pode dar uma olhada nesse link: https://refactoring.guru/design-patterns/command.
  Também é muito interessante o estudo de alguns padrões de arquitetura de software,
  como Domain Driven Design e Clean Architecture,
  pois você vai esbarrar no padrão de Command Handlers
  (que foi aplicado de forma bem simples nesta aula).
  */

/*
 *Um Command Handler tem como responsabilidade,
 *normalmente,
 *apenas orquestrar as tarefas a serem executadas, ou seja,
 * chamar as classes necessárias que realizam as tarefas desejadas.
 * No nosso caso,
 * o Command Handler tinha todo o código do fluxo em seu corpo.
 *
 * //Se torna mais coesos separar o commands em classes distintas...
 */

public class GeraPedidoHandler {


    public void executar(GeraPedido dados) {
        Orcamento orcamento = new Orcamento(dados.getValorOrcamento(), dados.getQtdeItens());
        dados.setPedido(new Pedido(dados.getCliente(), LocalDateTime.now(), orcamento));

        EnviaEmail email = new EnviaEmail(/*Dependencias*/);
        email.executar(dados.getPedido());
        SalvaBancoDados salva = new SalvaBancoDados(/*Dependencias*/);
        salva.executar(dados.getPedido());
    }
}
