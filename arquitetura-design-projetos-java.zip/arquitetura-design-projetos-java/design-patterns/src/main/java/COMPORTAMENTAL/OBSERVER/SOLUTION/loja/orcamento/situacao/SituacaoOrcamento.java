package COMPORTAMENTAL.OBSERVER.SOLUTION.loja.orcamento.situacao;

import COMPORTAMENTAL.OBSERVER.SOLUTION.loja.orcamento.Orcamento;
import COMPORTAMENTAL.OBSERVER.SOLUTION.loja.orcamento.exceptions.DomainException;

import java.math.BigDecimal;

public abstract class SituacaoOrcamento {

    public BigDecimal calcularValorDescontoExtra(Orcamento orcamento) {
        return BigDecimal.ZERO;
    }
    public void aprovar(Orcamento orcamento) throws DomainException {
        throw new DomainException("Oracamento nao pode ser aprovado!");
    }

    public void reprovar(Orcamento orcamento) throws DomainException {
        throw new DomainException("Oracamento nao pode ser reprovado!");
    }

    public void finalizar(Orcamento orcamento) throws DomainException {
        throw new DomainException("Oracamento nao pode ser finalizado!");
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName();
    }
}

