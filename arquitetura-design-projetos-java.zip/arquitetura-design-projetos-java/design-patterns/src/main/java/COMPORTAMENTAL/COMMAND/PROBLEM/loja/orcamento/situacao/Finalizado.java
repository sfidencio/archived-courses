package COMPORTAMENTAL.COMMAND.PROBLEM.loja.orcamento.situacao;

public class Finalizado extends SituacaoOrcamento {
    @Override
    public String toString() {
        return super.toString();
    }
}
