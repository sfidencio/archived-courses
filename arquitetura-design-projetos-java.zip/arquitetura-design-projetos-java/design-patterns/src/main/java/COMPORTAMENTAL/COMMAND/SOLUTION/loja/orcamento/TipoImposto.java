package COMPORTAMENTAL.COMMAND.SOLUTION.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
