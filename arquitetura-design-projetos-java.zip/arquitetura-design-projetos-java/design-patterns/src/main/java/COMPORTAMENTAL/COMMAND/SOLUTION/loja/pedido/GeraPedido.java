package COMPORTAMENTAL.COMMAND.SOLUTION.loja.pedido;

import COMPORTAMENTAL.COMMAND.SOLUTION.loja.orcamento.Orcamento;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class GeraPedido {

    private String cliente;
    private BigDecimal valorOrcamento;
    private int qtdeItens;

    private Pedido pedido;

    public GeraPedido(String cliente, BigDecimal valorOrcamento, int qtdeItens) {
        this.cliente = cliente;
        this.valorOrcamento = valorOrcamento;
        this.qtdeItens = qtdeItens;
    }

    public void executar(){
        Orcamento orcamento = new Orcamento(this.valorOrcamento,this.qtdeItens);
        LocalDateTime dataHora = LocalDateTime.now();
        this.pedido = new Pedido(cliente,dataHora,orcamento);
    }

    public  Pedido getPedido() {
        return this.pedido;
    }

    @Override
    public String toString() {
        if(this.pedido == null)
            throw  new RuntimeException("Pedido nao foi gerado. Gere primeiro o pedido!");
        return "GeraPedidoFacade{" +
                "cliente='" + cliente + '\'' +
                ", valorOrcamento=" + valorOrcamento +
                ", qtdeItens=" + qtdeItens +
                ", pedido=" + pedido +
                '}';
    }
}
