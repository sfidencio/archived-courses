package COMPORTAMENTAL.COMMAND.PROBLEM.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
