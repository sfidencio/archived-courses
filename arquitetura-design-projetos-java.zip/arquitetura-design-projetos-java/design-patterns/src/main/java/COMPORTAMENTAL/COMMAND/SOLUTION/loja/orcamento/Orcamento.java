package COMPORTAMENTAL.COMMAND.SOLUTION.loja.orcamento;

import COMPORTAMENTAL.COMMAND.SOLUTION.loja.orcamento.exceptions.DomainException;
import COMPORTAMENTAL.COMMAND.SOLUTION.loja.orcamento.situacao.EmAnalise;
import COMPORTAMENTAL.COMMAND.SOLUTION.loja.orcamento.situacao.SituacaoOrcamento;

import java.math.BigDecimal;

public class Orcamento {
    private BigDecimal valor;
    private int qtdItens;

    private SituacaoOrcamento situacao; //EM_ANALISE, APROVADO, REPROVADO, FINALIZADO


    public void aplicarDescontoExtra() {
        BigDecimal descontoExtra = this.situacao.calcularValorDescontoExtra(this);
        this.valor = this.valor.subtract(descontoExtra);
    }

    public Orcamento(BigDecimal valor) {
        this.valor = valor;
        this.situacao = new EmAnalise();
    }

    public Orcamento(BigDecimal valor, int qtdItens) {
        this.valor = valor;
        this.qtdItens = qtdItens;
        this.situacao = new EmAnalise();
    }

    public BigDecimal getValor() {
        return valor;
    }

    public int getQtdItens() {
        return qtdItens;
    }

    public void setSituacao(SituacaoOrcamento situacao) {
        this.situacao = situacao;
    }

    public SituacaoOrcamento getSituacao() {
        return situacao;
    }

    public void aprovar() throws DomainException {
        this.situacao.aprovar(this);
    }
    public void reprovar() throws DomainException {
        this.situacao.reprovar(this);
    }
    public void finalizar() throws DomainException {
        this.situacao.finalizar(this);
    }


    @Override
    public String toString() {
        return "Orcamento{" +
                "valor=" + valor +
                ", qtdItens=" + qtdItens +
                ", situacao=" + situacao +
                '}';
    }
}


