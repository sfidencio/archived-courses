package COMPORTAMENTAL.COMMAND.PROBLEM.loja;

import COMPORTAMENTAL.COMMAND.PROBLEM.loja.orcamento.CalculadoraDeDescontos;
import COMPORTAMENTAL.COMMAND.PROBLEM.loja.orcamento.Orcamento;
import COMPORTAMENTAL.COMMAND.PROBLEM.loja.pedido.Pedido;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TesteCriacaoOrcamentoExecucaoTarefasParalelas {

    public static void main(String[] args) {
        Orcamento primeiro = new Orcamento(new BigDecimal("200"),6);
        Orcamento segundo  = new Orcamento(new BigDecimal("1000"),1);
        Orcamento terceiro  = new Orcamento(new BigDecimal("20"),2);//Esse vai retornar zero..

        CalculadoraDeDescontos calculadoraDeDescontos = new CalculadoraDeDescontos();
        System.out.println(calculadoraDeDescontos.calcular(primeiro));
        System.out.println(calculadoraDeDescontos.calcular(segundo));
        System.out.println(calculadoraDeDescontos.calcular(terceiro));

        //Gerando pedido
        Pedido pedido1 = new Pedido("Teste1", LocalDateTime.now(),primeiro);
        System.out.println(pedido1);

    }
}
