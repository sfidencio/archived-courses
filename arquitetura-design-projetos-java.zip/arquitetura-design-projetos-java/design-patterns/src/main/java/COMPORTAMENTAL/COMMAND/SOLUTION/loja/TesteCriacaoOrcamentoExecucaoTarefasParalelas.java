package COMPORTAMENTAL.COMMAND.SOLUTION.loja;

import COMPORTAMENTAL.COMMAND.SOLUTION.loja.orcamento.CalculadoraDeDescontos;
import COMPORTAMENTAL.COMMAND.SOLUTION.loja.orcamento.Orcamento;
import COMPORTAMENTAL.COMMAND.SOLUTION.loja.pedido.GeraPedido;
import COMPORTAMENTAL.COMMAND.SOLUTION.loja.pedido.Pedido;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TesteCriacaoOrcamentoExecucaoTarefasParalelas {

    public static void main(String[] args) {
        Orcamento primeiro = new Orcamento(new BigDecimal("200"),6);
        Orcamento segundo  = new Orcamento(new BigDecimal("1000"),1);
        Orcamento terceiro  = new Orcamento(new BigDecimal("20"),2);//Esse vai retornar zero..

        CalculadoraDeDescontos calculadoraDeDescontos = new CalculadoraDeDescontos();
        System.out.println(calculadoraDeDescontos.calcular(primeiro));
        System.out.println(calculadoraDeDescontos.calcular(segundo));
        System.out.println(calculadoraDeDescontos.calcular(terceiro));

        //Gerando pedido  - aplicando o pattern command
        //Observe que delegamos a geracao do pedido para classe GeraPedidoFacade
        GeraPedido geraPedido = new GeraPedido("Cliente1",new BigDecimal("200.00"),6);
        geraPedido.executar();
        System.out.println(geraPedido);

    }
}
