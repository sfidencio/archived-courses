package ESTRUTURAL.ADAPTER.PROBLEM.loja.pedido3.actions;

import ESTRUTURAL.ADAPTER.PROBLEM.loja.pedido3.AcaoAposGerarPedido;
import ESTRUTURAL.ADAPTER.PROBLEM.loja.pedido3.Pedido;

public class GravaMensagemFilaKafka implements AcaoAposGerarPedido {
    @Override
    public void executar(Pedido pedido) {
        System.out.println("Salvar topico do KAFKA ->" + pedido);
    }

}
