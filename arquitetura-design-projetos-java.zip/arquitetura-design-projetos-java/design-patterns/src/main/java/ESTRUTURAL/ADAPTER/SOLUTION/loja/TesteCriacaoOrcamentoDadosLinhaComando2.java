package ESTRUTURAL.ADAPTER.SOLUTION.loja;
import ESTRUTURAL.ADAPTER.SOLUTION.loja.pedido2.GeraPedido;
import ESTRUTURAL.ADAPTER.SOLUTION.loja.pedido2.GeraPedidoHandler;

import java.math.BigDecimal;

public class TesteCriacaoOrcamentoDadosLinhaComando2 {

    public static void main(String[] args) {
        //Gerando pedido  - aplicando o pattern command dados linha comando
        //Observe que delegamos a geracao do pedido para classe GeraPedidoFacade
        GeraPedido geraPedido = new GeraPedido("CLIENTE 2",new BigDecimal("200.20"),4);
        GeraPedidoHandler handler = new GeraPedidoHandler(/*dependencias ->@services, @repository*/);
        handler.executar(geraPedido);
        System.out.println(geraPedido.getPedido());
    }
}
