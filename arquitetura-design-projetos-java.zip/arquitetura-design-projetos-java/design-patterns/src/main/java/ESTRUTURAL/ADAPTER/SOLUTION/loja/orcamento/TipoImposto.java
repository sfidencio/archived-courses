package ESTRUTURAL.ADAPTER.SOLUTION.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
