package ESTRUTURAL.ADAPTER.SOLUTION.loja.orcamento;

import ESTRUTURAL.ADAPTER.SOLUTION.loja.orcamento.exceptions.DomainException;
import ESTRUTURAL.ADAPTER.SOLUTION.loja.orcamento.http.JavaHttpAdapter;

import java.io.IOException;
import java.math.BigDecimal;

public class TesteAdapter {
    public static void main(String[] args) throws DomainException, IOException {
        Orcamento orcamento = new Orcamento(BigDecimal.TEN,1);
        orcamento.aprovar();
        orcamento.finalizar();
        RegistroOrcamento registroOrcamento = new RegistroOrcamento(new JavaHttpAdapter());
        registroOrcamento.registrar(orcamento);
    }
}
