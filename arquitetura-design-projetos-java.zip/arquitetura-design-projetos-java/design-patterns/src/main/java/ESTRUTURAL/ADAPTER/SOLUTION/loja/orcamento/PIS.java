package ESTRUTURAL.ADAPTER.SOLUTION.loja.orcamento;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class PIS implements Imposto {
    @Override
    public BigDecimal calcular(Orcamento orcamento) {
        return orcamento.getValor().multiply(new BigDecimal("0.076")).setScale(2, RoundingMode.HALF_UP);
    }
}
