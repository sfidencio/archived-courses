package ESTRUTURAL.ADAPTER.SOLUTION.loja.orcamento.http;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Map;

public interface HttpAdapterExemple {
    void post(String url, Map<String, Object> dados) throws IOException;
}
