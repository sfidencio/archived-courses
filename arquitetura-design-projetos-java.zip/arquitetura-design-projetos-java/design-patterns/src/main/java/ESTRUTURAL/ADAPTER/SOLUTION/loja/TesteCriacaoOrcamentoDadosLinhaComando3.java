package ESTRUTURAL.ADAPTER.SOLUTION.loja;

import ESTRUTURAL.ADAPTER.SOLUTION.loja.pedido3.EnviaEmail;
import ESTRUTURAL.ADAPTER.SOLUTION.loja.pedido3.GeraPedidoHandler;
import ESTRUTURAL.ADAPTER.SOLUTION.loja.pedido3.actions.GeraPedido;
import ESTRUTURAL.ADAPTER.SOLUTION.loja.pedido3.actions.GravaMensagemFilaKafka;
import ESTRUTURAL.ADAPTER.SOLUTION.loja.pedido3.actions.SalvaBancoDados;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;

public class TesteCriacaoOrcamentoDadosLinhaComando3 {

    public static void main(String[] args) {
        //Gerando pedido  - aplicando o pattern command dados linha comando
        //Observe que delegamos a geracao do pedido para classe GeraPedidoFacade
        GeraPedido geraPedido = new GeraPedido("CLIENTE 3", new BigDecimal("400.20"), 4);
        //GeraPedidoHandler handler = new GeraPedidoHandler(/*dependencias ->@services, @repository*/);
        GeraPedidoHandler handler = new GeraPedidoHandler(new ArrayList<>(Arrays.asList(new EnviaEmail(), new SalvaBancoDados(),new GravaMensagemFilaKafka())));
        handler.executar(geraPedido);
        System.out.println(geraPedido.getPedido());
    }
}
