package ESTRUTURAL.ADAPTER.PROBLEM.loja.pedido3;

public interface AcaoAposGerarPedido {
    void executar(Pedido pedido);
}
