package ESTRUTURAL.ADAPTER.SOLUTION.loja;

import ESTRUTURAL.ADAPTER.SOLUTION.loja.pedido.GeraPedido;

import java.math.BigDecimal;

public class TesteCriacaoOrcamentoDadosLinhaComando {

    public static void main(String[] args) {
        //Gerando pedido  - aplicando o pattern command dados linha comando
        //Observe que delegamos a geracao do pedido para classe GeraPedidoFacade
        GeraPedido geraPedido = new GeraPedido(args[0],new BigDecimal(args[1]),Integer.parseInt(args[2]));
        geraPedido.executar();
        System.out.println(geraPedido);

    }
}
