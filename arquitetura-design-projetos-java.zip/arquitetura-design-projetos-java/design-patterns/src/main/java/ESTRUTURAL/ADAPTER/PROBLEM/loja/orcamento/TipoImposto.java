package ESTRUTURAL.ADAPTER.PROBLEM.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
