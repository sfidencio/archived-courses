package ESTRUTURAL.COMPOSITE.PROBLEM.loja;

import ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento.CalculadoraDeDescontos;
import ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento.Orcamento;
import ESTRUTURAL.COMPOSITE.PROBLEM.loja.pedido.GeraPedido;

import java.math.BigDecimal;

public class TesteCriacaoOrcamentoExecucaoTarefasParalelas {

    public static void main(String[] args) {
        Orcamento primeiro = new Orcamento();
        Orcamento segundo  = new Orcamento();
        Orcamento terceiro  = new Orcamento();//Esse vai retornar zero..

        CalculadoraDeDescontos calculadoraDeDescontos = new CalculadoraDeDescontos();
        System.out.println(calculadoraDeDescontos.calcular(primeiro));
        System.out.println(calculadoraDeDescontos.calcular(segundo));
        System.out.println(calculadoraDeDescontos.calcular(terceiro));

        //Gerando pedido  - aplicando o pattern command
        //Observe que delegamos a geracao do pedido para classe GeraPedidoFacade
        GeraPedido geraPedido = new GeraPedido("Cliente1",new BigDecimal("200.00"),6);
        geraPedido.executar();
        System.out.println(geraPedido);

    }
}
