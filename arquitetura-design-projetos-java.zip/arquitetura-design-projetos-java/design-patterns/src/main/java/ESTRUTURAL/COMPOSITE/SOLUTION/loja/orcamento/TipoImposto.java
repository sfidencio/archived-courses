package ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
