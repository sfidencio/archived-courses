package ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento.situacao;
import ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento.Orcamento;

public class Reprovado extends SituacaoOrcamento {

    @Override
    public void finalizar(Orcamento orcamento) {
        orcamento.setSituacao(new Finalizado());
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
