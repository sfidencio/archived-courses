package ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento;

public enum TipoImposto {
    ICMS,ISS
}
