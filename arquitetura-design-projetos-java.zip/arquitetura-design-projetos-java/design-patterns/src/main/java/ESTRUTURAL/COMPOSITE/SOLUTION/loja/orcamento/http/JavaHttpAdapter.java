package ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento.http;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Map;

public class JavaHttpAdapter implements HttpAdapterExemple {
    @Override
    public void post(String url, Map<String, Object> dados) throws IOException {
        URL urlApi = new URL(url);
        URLConnection connection = urlApi.openConnection();
        System.out.println(connection.getContent());
    }
}
