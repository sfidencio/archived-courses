package ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento;

import java.math.BigDecimal;

public class TesteComposite {
    public static void main(String[] args) {
        Orcamento primeiro = new Orcamento();
        primeiro.adicionarItem(new ItemOrcamento(new BigDecimal("200.00")));

        CalculadoraDeDescontos calculadoraDeDescontos = new CalculadoraDeDescontos();
        System.out.println(calculadoraDeDescontos.calcular(primeiro));

    }
}
