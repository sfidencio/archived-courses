package ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento.descontos;

import ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento.Orcamento;

import java.math.BigDecimal;

public abstract class Desconto {
    protected Desconto proximo;

    public Desconto(Desconto proximo) {
        this.proximo = proximo;
    }

    //TemplateMethod
    //Colocamos a regra que verifica se deve calcular ou nao..na classe abstrata
    public BigDecimal calcular(Orcamento orcamento) {
      if(deveAplicar(orcamento))
          return efetuarCalculo(orcamento);
      return proximo.calcular(orcamento);
    }
    protected abstract BigDecimal efetuarCalculo(Orcamento orcamento);


    protected abstract Boolean deveAplicar(Orcamento orcamento);
}
