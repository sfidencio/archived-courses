package ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento;

import ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento.exceptions.DomainException;
import ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento.http.JavaHttpAdapter;

import java.io.IOException;
import java.math.BigDecimal;

public class TesteAdapter {
    public static void main(String[] args) throws DomainException, IOException {
        Orcamento orcamento = new Orcamento();
        orcamento.aprovar();
        orcamento.finalizar();
        RegistroOrcamento registroOrcamento = new RegistroOrcamento(new JavaHttpAdapter());
        registroOrcamento.registrar(orcamento);
    }
}
