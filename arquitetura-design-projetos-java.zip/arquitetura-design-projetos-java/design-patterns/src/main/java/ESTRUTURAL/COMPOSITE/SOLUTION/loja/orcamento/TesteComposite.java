package ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento;

import ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento.exceptions.DomainException;

import java.math.BigDecimal;

public class TesteComposite {
    public static void main(String[] args) throws DomainException {
        Orcamento orcamentoAntigo = new Orcamento();
        orcamentoAntigo.adicionarItem(new ItemOrcamento(new BigDecimal("200.00")));
        orcamentoAntigo.reprovar();

        System.out.println(orcamentoAntigo);

        Orcamento orcamentoNovo = new Orcamento();
        orcamentoNovo.adicionarItem(new ItemOrcamento(new BigDecimal("500")));

        //Compatibilizar Orcamento com itemOrcamento
        orcamentoNovo.adicionarItem(orcamentoAntigo);

        System.out.println(orcamentoNovo);

    }
}
