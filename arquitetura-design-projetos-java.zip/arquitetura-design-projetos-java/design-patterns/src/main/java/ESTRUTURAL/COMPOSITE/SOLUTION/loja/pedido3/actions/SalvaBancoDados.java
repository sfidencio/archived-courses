package ESTRUTURAL.COMPOSITE.SOLUTION.loja.pedido3.actions;

import ESTRUTURAL.COMPOSITE.SOLUTION.loja.pedido3.AcaoAposGerarPedido;
import ESTRUTURAL.COMPOSITE.SOLUTION.loja.pedido3.Pedido;

/*https://refactoring.guru/design-patterns/observer*/
/*Trata-se de um ouvinte ou observador esta classe, pois foi registrada  pra ser chamada pelo handler ou manipular*/
public class SalvaBancoDados implements AcaoAposGerarPedido {
    @Override
    public void executar(Pedido pedido) {
        System.out.println("Salvar pedido banco de dados ->" + pedido);
    }
}
