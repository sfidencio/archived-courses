package ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento;

import java.math.BigDecimal;

public class TesteCalculadoraDescontos {

    public static void main(String[] args) {
        Orcamento primeiro = new Orcamento();
        Orcamento segundo = new Orcamento();
        Orcamento terceiro = new Orcamento();//Esse vai retornar zero..

        CalculadoraDeDescontos calculadoraDeDescontos = new CalculadoraDeDescontos();
        System.out.println(calculadoraDeDescontos.calcular(primeiro));
        System.out.println(calculadoraDeDescontos.calcular(segundo));
        System.out.println(calculadoraDeDescontos.calcular(terceiro));
    }
}
