package ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento.http;

import java.io.IOException;
import java.util.Map;

public interface HttpAdapterExemple {
    void post(String url, Map<String, Object> dados) throws IOException;
}
