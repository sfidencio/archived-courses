package ESTRUTURAL.COMPOSITE.SOLUTION.loja.pedido3;

/*https://refactoring.guru/design-patterns/observer*/

/*Trata-se de um ouvinte ou observador esta classe, pois foi registrada  pra ser chamada pelo handler ou manipular*/
public class EnviaEmail implements AcaoAposGerarPedido {
    @Override
    public void executar(Pedido pedido) {
        System.out.println("Email enviado para pedido ->" + pedido);
    }
}
