package ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento;

import ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento.exceptions.DomainException;
import ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento.situacao.EmAnalise;
import ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento.situacao.Finalizado;
import ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento.situacao.SituacaoOrcamento;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Orcamento implements Orcavel {
    private BigDecimal valor;
    private List<Orcavel> itens;

    private SituacaoOrcamento situacao; //EM_ANALISE, APROVADO, REPROVADO, FINALIZADO


    public Orcamento() {
        this.valor = BigDecimal.ZERO;
        this.itens = new ArrayList<>();
        this.situacao = new EmAnalise();
    }


    public void aplicarDescontoExtra() {
        BigDecimal descontoExtra = this.situacao.calcularValorDescontoExtra(this);
        this.valor = this.valor.subtract(descontoExtra);
    }

    /*public Orcamento(BigDecimal valor) {
        this.valor = valor;
        this.situacao = new EmAnalise();
    }*/


    public BigDecimal getValor() {
        return valor;
    }

    public int getQtdItens() {
        return itens.size();
    }

    public void setSituacao(SituacaoOrcamento situacao) {
        this.situacao = situacao;
    }

    public SituacaoOrcamento getSituacao() {
        return situacao;
    }

    public void aprovar() throws DomainException {
        this.situacao.aprovar(this);
    }

    public void reprovar() throws DomainException {
        this.situacao.reprovar(this);
    }

    public void finalizar() throws DomainException {
        this.situacao.finalizar(this);
    }


    @Override
    public String toString() {
        return "Orcamento{" +
                "valor=" + valor +
                ", qtdItens=" + this.itens.size() +
                ", situacao=" + situacao +
                '}';
    }

    public boolean isFinalizado() {
        return situacao instanceof Finalizado;
    }

    public void adicionarItem(Orcavel item) {
        this.valor = this.valor.add(item.getValor());
        this.itens.add(item);
    }
}


