package ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento;

import java.math.BigDecimal;

public class TesteCalculadoraImpostosICMSComISS {
    public static void main(String[] args) {
        Orcamento orcamento = new Orcamento();
        ICMSComISS calculadoraDeImpostos = new ICMSComISS();

        BigDecimal resultadoICMS = calculadoraDeImpostos.calcular(orcamento);
        System.out.println("Calculo ICMS + ISS: " + resultadoICMS);
    }
}
