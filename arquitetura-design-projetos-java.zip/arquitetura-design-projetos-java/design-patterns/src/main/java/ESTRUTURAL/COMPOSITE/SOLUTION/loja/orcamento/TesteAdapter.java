package ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento;

import ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento.exceptions.DomainException;
import ESTRUTURAL.COMPOSITE.SOLUTION.loja.orcamento.http.JavaHttpAdapter;

import java.io.IOException;

public class TesteAdapter {
    public static void main(String[] args) throws DomainException, IOException {
        Orcamento orcamento = new Orcamento();
        orcamento.aprovar();
        orcamento.finalizar();
        RegistroOrcamento registroOrcamento = new RegistroOrcamento(new JavaHttpAdapter());
        registroOrcamento.registrar(orcamento);
    }
}
