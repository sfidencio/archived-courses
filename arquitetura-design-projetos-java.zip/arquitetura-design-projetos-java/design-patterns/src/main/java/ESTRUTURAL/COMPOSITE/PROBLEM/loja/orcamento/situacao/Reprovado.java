package ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento.situacao;
import ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento.Orcamento;

public class Reprovado extends SituacaoOrcamento {

    @Override
    public void finalizar(Orcamento orcamento) {
        orcamento.setSituacao(new Finalizado());
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
