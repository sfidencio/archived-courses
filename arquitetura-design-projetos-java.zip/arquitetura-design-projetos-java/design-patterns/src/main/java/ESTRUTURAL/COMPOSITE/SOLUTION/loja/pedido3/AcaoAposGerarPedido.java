package ESTRUTURAL.COMPOSITE.SOLUTION.loja.pedido3;

public interface AcaoAposGerarPedido {
    void executar(Pedido pedido);
}
