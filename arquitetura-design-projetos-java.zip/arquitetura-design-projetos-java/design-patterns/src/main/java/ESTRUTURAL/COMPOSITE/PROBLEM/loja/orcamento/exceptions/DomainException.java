package ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento.exceptions;

public class DomainException extends Throwable {
    public DomainException(String s) {
        super(s);
    }
}
