package ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento;

import ESTRUTURAL.COMPOSITE.PROBLEM.loja.orcamento.descontos.Desconto;

import java.math.BigDecimal;

public class SemDesconto extends Desconto {
    public SemDesconto() {
        super(null);
    }

    public BigDecimal efetuarCalculo(Orcamento orcamento) {
        return BigDecimal.ZERO;
    }

    @Override
    protected Boolean deveAplicar(Orcamento orcamento) {
        return true;
    }
}
