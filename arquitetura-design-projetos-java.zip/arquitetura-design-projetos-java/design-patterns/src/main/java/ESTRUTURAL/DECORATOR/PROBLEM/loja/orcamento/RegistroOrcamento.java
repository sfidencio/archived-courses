package ESTRUTURAL.DECORATOR.PROBLEM.loja.orcamento;

import ESTRUTURAL.DECORATOR.PROBLEM.loja.orcamento.exceptions.DomainException;
import ESTRUTURAL.DECORATOR.PROBLEM.loja.orcamento.http.HttpAdapterExemple;

import java.io.IOException;
import java.util.Map;

public class RegistroOrcamento {

private HttpAdapterExemple httpAdapterExemple;

    public RegistroOrcamento(HttpAdapterExemple httpAdapterExemple) {
        this.httpAdapterExemple = httpAdapterExemple;
    }

    public void registrar(Orcamento orcamento) throws DomainException, IOException {
        //Chamada HTTP api externa - exemplo
        //Url Connection
        //HttpClient
        //RestTemplate
        //Misturando detalhes de infra.
        //Vamos abstrair?

        if(!orcamento.isFinalizado())
            throw  new DomainException("Orcamento nao finalizado!");

        Map<String,Object> dados = Map.of("valor",orcamento.getValor(),"qtdItens", orcamento.getQtdItens()) ;
        this.httpAdapterExemple.post("http://www.google.com",dados);
    }
}
