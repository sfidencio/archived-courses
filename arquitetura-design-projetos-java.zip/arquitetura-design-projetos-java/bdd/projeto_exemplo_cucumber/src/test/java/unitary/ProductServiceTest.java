package unitary;

import business.Product;
import business.ProductService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import java.math.BigDecimal;
import java.util.ArrayList;

class ProductServiceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void registerNewProduct() {
        Product p1 = Product.builder()
                .id(1)
                .description("Apple")
                .price(new BigDecimal("2.99"))
                .build();
        ProductService productService = new ProductService(new ArrayList<>(0));
        productService.registerNewProduct(p1);
        Assertions.assertEquals(1,productService.getAllProducts().size());
    }
}