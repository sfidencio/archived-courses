package acceptance;


import business.Product;
import business.ProductService;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class registerProduct {

    private ProductService productService = new ProductService(new ArrayList<>(0));
    private Product product;


    @BeforeEach
    public void setUp() {
        System.out.println("Run each test");
    }


    @Given("product0 name register valid")
    public void product0_name_register_valid() {

    }
    @When("Try register product0 with success")
    public void try_register_product0_with_success() {

    }
    @Then("registration product0 is completed successfully")
    public void registration_product0_is_completed_successfully() {

    }


    @Given("product name {string} register valid with price {double}")
    public void product_name_register_valid_with_price(String description, Double price) {
        this.product = Product.builder()
                .id(1)
                .description(description)
                .price(BigDecimal.valueOf(price))
                .build();
        System.out.println(product);
        //throw new io.cucumber.java.PendingException();
    }

    @When("Try register product with success")
    public void try_register_product_with_success() {
        this.productService = new ProductService(new ArrayList<>(0));
        this.productService.registerNewProduct(this.product);
        Assertions.assertEquals(1, this.productService.getAllProducts().size());
    }

    @Then("registration is completed successfully")
    public void registration_is_completed_successfully() {
        Assertions.assertTrue(this.productService.getAllProducts().get(0).getPrice().doubleValue() < 3.0);
        this.productService = new ProductService(new ArrayList<>());
    }


    @Given("product1 name {string} register valid with price {double}")
    public void product1_name_register_valid_with_price(String description, Double price) {
        System.out.println("Cenario 1");
        this.product = Product.builder()
                .id(1)
                .description(description)
                .price(BigDecimal.valueOf(price))
                .build();
        System.out.println(product);
        //this.productService = new ProductService(new ArrayList<>(0));
        this.productService.registerNewProduct(product);
        // Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
    }

    @And("aproduct1 name {string} register valid with price {double}")
    public void aproduct1_name_register_valid_with_price(String description, Double price) {
        System.out.println("Cenario 2");
        this.product = Product.builder()
                .id(1)
                .description(description)
                .price(BigDecimal.valueOf(price))
                .build();
        System.out.println(product);
        //this.productService = new ProductService(new ArrayList<>(0));
        this.productService.registerNewProduct(product);
        // Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
    }

    @When("Try register product1 with success")
    public void try_register_product1_with_success() {
        Assertions.assertEquals(
                2, this.productService.getAllProducts().size());
    }
    @Then("registration product1 is completed successfully")
    public void registration_product1_is_completed_successfully() {
        //Assertions.assertTrue(this.productService.getAllProducts().get(0).getPrice().doubleValue() < 3.0);
    }

    /*@Given("^product3 name {string} register valid with price '([\\d\\.]+)'$")
    public void product3_name_register_valid_with_price(String string1, String string2) {

    }*/

    @Given("product name {string} register invalid with price {double}")
    public void product_name_register_invalid_with_price(String description, Double price) {
        this.product = Product.builder()
                .id(1)
                .description(description)
                .price(BigDecimal.valueOf(price))
                .build();
        System.out.println(product);
        //throw new io.cucumber.java.PendingException();
    }
    @When("Try register product invalid")
    public void try_register_product() {
        this.productService = new ProductService(new ArrayList<>(0));
        Assertions.assertThrows(IllegalArgumentException.class,()-> this.productService.registerNewProduct(this.product));
    }
    @Then("registration is failed")
    public void registration_is_failed() {
        // Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
    }

    @Given("product7 name {string} register valid with price {double}")
    public void product7_name_register_valid_with_price(String string, Double string2) {
        System.out.println(string + "->" + string2);
    }
    @When("Try register product7 valid")
    public void try_register_product7_valid() {

    }
    @Then("registration product7 is completed successfully")
    public void registration_product7_is_completed_successfully() {

    }




    @Given("four products")
    public void four_products(DataTable dataTable) {
        // Write code here that turns the phrase above into concrete actions
        // For automatic transformation, change DataTable to one of
        // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
        // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
        // Double, Byte, Short, Long, BigInteger or BigDecimal.
        //
        // For other transformations you can register a DataTableType.
        //throw new io.cucumber.java.PendingException();
        List<Map<String,String>> lista = dataTable.asMaps();
        //lista.forEach(System.out::println);
        for (Map<String, String> item : lista) {
            System.out.println(item.get("description"));
            System.out.println(item.get("price"));
        }


    }

    @Given("five products")
    public void five_products(io.cucumber.datatable.DataTable dataTable) {
        // Write code here that turns the phrase above into concrete actions
        // For automatic transformation, change DataTable to one of
        // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
        // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
        // Double, Byte, Short, Long, BigInteger or BigDecimal.
        //
        // For other transformations you can register a DataTableType.
        //throw new io.cucumber.java.PendingException();
        var lista = dataTable.asList();
        System.out.println(lista);
    }






}
