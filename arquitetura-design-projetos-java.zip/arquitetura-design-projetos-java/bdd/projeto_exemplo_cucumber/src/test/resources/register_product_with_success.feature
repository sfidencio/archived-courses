# new feature
# Tags: optional
# GerkinSyntax

Feature: e-commerce system

  #Without REGEX
  Scenario: register one product without parameters
    Given product0 name register valid
    When Try register product0 with success
    Then registration product0 is completed successfully

  #Without REGEX e with parameters
  Scenario: register one product
    Given product name "apple" register valid with price 2.78
    When Try register product with success
    Then registration is completed successfully

   #Without REGEX e with parameters
  Scenario: register two products
    Given product1 name "apple" register valid with price 2.78
    And aproduct1 name "orange" register valid with price 4.80
    When Try register product1 with success
    Then registration product1 is completed successfully

 #With REGEX
 # Scenario: register one product3 without parameters
 #   Given product3 name "banana" register valid with price "1.49"


  Scenario: register one product invalid
    Given product name "apple" register invalid with price 10.9
    When Try register product invalid
    Then registration is failed

#Scenario with outlines examples
  Scenario Outline: register one product7
    Given product7 name '<description>' register valid with price <price>
    When Try register product7 valid
    Then registration product7 is completed successfully
    Examples:
      | description | price |
      | Apple       | 2.79  |
      | Orange      | 4.60  |
      | Banana      | 9.9   |

#Scenario with datatable
  Scenario: register two products datatable map
    Given four products
      | description | price |
      | Apple       | 2.79  |
      | Orange      | 4.60  |
      | Banana      | 9.9   |

#Scenario with datatable
  Scenario: register two products datatable list simple
    Given five products
      | description |
      | Apple       |
      | Orange      |
      | Banana      |
      | Banana      |

