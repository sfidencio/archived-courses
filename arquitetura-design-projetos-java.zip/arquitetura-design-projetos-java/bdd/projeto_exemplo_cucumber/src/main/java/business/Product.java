package business;
import lombok.*;

import java.math.BigDecimal;

@Data
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Product {
    private int id;
    private String description;
    private BigDecimal price;
}
