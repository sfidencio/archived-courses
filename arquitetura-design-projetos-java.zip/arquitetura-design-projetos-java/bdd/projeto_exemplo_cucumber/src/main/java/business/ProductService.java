package business;

import java.util.Collections;
import java.util.List;

public class ProductService {

    private List<Product> listStore;

    public ProductService(List<Product> listStore) {
        this.listStore = listStore;
    }

    public void registerNewProduct(Product newProduct) {
        if (newProduct.getPrice().doubleValue() > 10.0)
            throw new IllegalArgumentException("Invalid value for the product!");
        this.listStore.add(newProduct);
    }

    public List<Product> getAllProducts() {
        return Collections.unmodifiableList(this.listStore);
    }
}
