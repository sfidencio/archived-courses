# new feature
# Tags: optional
# language: en
# https://cucumber.io/docs/gherkin/languages/

Feature: Cadastrando cliente

Scenario: Cadastrando cliente com sucesso
  Given Dado um cadastro valido
    When Quando tenta cadastrar um novo cliente
      Then Entao o cadastro é realizado com sucesso

#Scenario: Cadastrando varios clientes
#  Given Dado varios cadastros validos
#    When Quando tenta cadastrar varios clientes
#      Then Entao os cadastros sao realizados com sucesso
