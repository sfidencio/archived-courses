# new feature
# Tags: optional
# language: en
# https://cucumber.io/docs/gherkin/languages/

Feature: Ocupando Vaga

Scenario: Ocupando Vaga
  Given Dado um cliente valido ja cadastrado
    When Quando tenta ocupar vaga
      Then Entao a vaga disponivel e ocupada com sucesso

Scenario: Ocupando Vaga 2
    Given Dado um cliente valido ja cadastrado cujo nome e "Teste 1"
    When Quando tenta ocupar vaga
    Then Entao a vaga disponivel e ocupada com sucesso

#Scenario: Cadastrando varios clientes
#  Given Dado varios cadastros validos
#    When Quando tenta cadastrar varios clientes
#      Then Entao os cadastros sao realizados com sucesso
