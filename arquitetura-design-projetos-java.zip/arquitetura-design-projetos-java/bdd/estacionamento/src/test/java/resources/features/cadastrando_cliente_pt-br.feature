# Linguagem Gherkin
# new feature
# Tags: optional
# language: pt
# https://cucumber.io/docs/gherkin/languages/

Funcionalidade: : Cadastrando cliente

  Cenario:  Cadastrando cliente com sucesso
    Dado: um cadastro valido
      Quando: tenta cadastrar um novo cliente
        Entao:  o cadastro é realizado com sucesso