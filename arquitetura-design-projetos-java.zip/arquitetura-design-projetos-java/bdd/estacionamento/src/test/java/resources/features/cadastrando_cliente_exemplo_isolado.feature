# new feature
# Tags: optional
# language: en
# https://cucumber.io/docs/gherkin/languages/

Feature: Cadastrando cliente Isolado

Scenario: Cadastrando cliente com sucesso isolado
  Given Dado um cadastro valido cujo nome "Teste 2" e status "ATIVO" isolado
    When Quando tenta cadastrar um novo cliente isolado
      Then Entao o cadastro é realizado com sucesso isolado