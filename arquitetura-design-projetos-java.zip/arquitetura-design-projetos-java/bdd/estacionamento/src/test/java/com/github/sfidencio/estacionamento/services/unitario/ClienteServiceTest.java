package com.github.sfidencio.estacionamento.services.unitario;

import com.github.sfidencio.estacionamento.config.DomainException;
import com.github.sfidencio.estacionamento.config.NotFoundException;
import com.github.sfidencio.estacionamento.model.Cliente;
import com.github.sfidencio.estacionamento.model.Status;
import com.github.sfidencio.estacionamento.repository.ClienteRepository;
import com.github.sfidencio.estacionamento.services.ClienteService;
import org.junit.jupiter.api.*;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@SpringBootTest
@ActiveProfiles("dev")
class ClienteServiceTest {

    @Mock
    private ClienteRepository clienteRepository;
    @InjectMocks
    private ClienteService clienteService = new ClienteService();
    private Cliente clienteSalvo;



    @BeforeEach
    void setUp() {
        clienteSalvo = Cliente.builder()
                .id(1)
                .nome("Teste")
                .status(Status.ATIVO)
                .build();
    }


    @Test
    @Order(1)
    @DisplayName("Deveria cadastrar com sucesso")
    void deveria_cadastrar_com_sucesso() throws DomainException {
        this.clienteService.cadastrar(clienteSalvo);
        Mockito.verify(this.clienteRepository).save(BDDMockito.any());
    }

    @Test
    @Order(2)
    @DisplayName("Deveria impedir o cadastramento devido a existencia do cliente")
    void deveria_impedir_cadastramento_devido_existencia_cliente() {
        Mockito.when(this.clienteRepository.findByNome(BDDMockito.any())).thenReturn(Optional.ofNullable(clienteSalvo));
        Assertions.assertThrows(DomainException.class, () -> this.clienteService.cadastrar(clienteSalvo));
    }

    @Test
    @Order(3)
    @DisplayName("Deveria cancelar ou inativar")
    void deveria_cancelar_ou_inativar_cadastro_cliente() throws NotFoundException {
       var clienteSalvoInativo = Cliente.builder()
                .id(1)
                .nome("Teste")
                .status(Status.INATIVO)
                .build();
        Mockito.when(this.clienteRepository.findById(BDDMockito.any())).thenReturn(Optional.ofNullable(clienteSalvoInativo));
        this.clienteService.cancelar(BDDMockito.anyInt());
        Mockito.verify(this.clienteRepository).findById(BDDMockito.anyInt());
        Mockito.verify(this.clienteRepository).save(BDDMockito.any());
    }

    @Test
    @Order(4)
    @DisplayName("Deveria nao cancelar ou inativar devido cliente nao existir")
    void deveria_nao_cancelar_ou_inativar_cadastro_cliente_cliente_nao_existe() {
        Mockito.when(this.clienteRepository.findById(BDDMockito.any())).thenReturn(Optional.empty());
        Assertions.assertThrows(NotFoundException.class, () -> this.clienteService.cancelar(BDDMockito.anyInt()));
    }

    @Test
    @Order(5)
    @DisplayName("Lista todos clientes cadastrados")
    void listar() {
        Cliente Cliente1 = Cliente.builder()
                .id(1)
                .nome("Teste")
                .status(Status.INATIVO)
                .build();
        Cliente Cliente2 = Cliente.builder()
                .id(2)
                .nome("Teste2")
                .status(Status.ATIVO)
                .build();
        List<Cliente> lista = new ArrayList<>();
        lista.add(Cliente1);
        lista.add(Cliente2);
        Mockito.when(this.clienteRepository.findAll()).thenReturn(lista);
        this.clienteService.listar();
        Mockito.verify(this.clienteRepository).findAll();
    }

    @Test
    @Order(6)
    @DisplayName("Pesquisa unico cliente com sucesso")
    void deveria_pesquisar_unico_cliente_pelo_id() throws NotFoundException {
        Cliente cliente = Cliente.builder()
                .id(1)
                .nome("Teste")
                .status(Status.INATIVO)
                .build();
        Mockito.when(this.clienteRepository.findById(BDDMockito.anyInt())).thenReturn(Optional.ofNullable(cliente));
        var retorno = this.clienteService.obterPorId(BDDMockito.anyInt());
        Assertions.assertEquals(Status.INATIVO,retorno.getStatus());
    }
}