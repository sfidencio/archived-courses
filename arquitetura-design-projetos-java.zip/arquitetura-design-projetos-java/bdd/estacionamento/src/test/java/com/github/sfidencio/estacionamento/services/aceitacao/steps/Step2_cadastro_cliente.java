package com.github.sfidencio.estacionamento.services.aceitacao.steps;

//import io.cucumber.spring.CucumberContextConfiguration;
import com.github.sfidencio.estacionamento.model.Cliente;
import com.github.sfidencio.estacionamento.model.Status;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
//@CucumberContextConfiguration
@Slf4j
public class Step2_cadastro_cliente {

    @Given("Dado um cadastro valido cujo nome {string} e status {string} isolado")
    public void dado_um_cadastro_valido_cujo_nome_e_status(String nome, String status) {
        Cliente cliente = Cliente.builder()
                .id(1)
                .nome(nome)
                .status(Status.valueOf(status))
                .build();
        System.out.println(cliente);
        // Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
    }

    @When("Quando tenta cadastrar um novo cliente isolado")
    public void quando_tenta_cadastrar_um_novo_cliente_isolado() {
        // Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
    }
    @Then("Entao o cadastro é realizado com sucesso isolado")
    public void entao_o_cadastro_é_realizado_com_sucesso_isolado() {
        // Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
    }


}
