package com.github.sfidencio.estacionamento.services.unitario;

import com.github.sfidencio.estacionamento.config.NotFoundException;
import com.github.sfidencio.estacionamento.model.Cliente;
import com.github.sfidencio.estacionamento.model.Status;
import com.github.sfidencio.estacionamento.model.Vaga;
import com.github.sfidencio.estacionamento.repository.ClienteRepository;
import com.github.sfidencio.estacionamento.repository.HistoricoRepository;
import com.github.sfidencio.estacionamento.repository.VagaRepository;
import com.github.sfidencio.estacionamento.services.VagaService;
import org.junit.jupiter.api.*;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@SpringBootTest
class VagaServiceTest {
    @Mock
    private VagaRepository vagaRepository;
    @Mock
    private HistoricoRepository historicoRepository;
    @Mock
    private ClienteRepository clienteRepository;
    @InjectMocks
    private VagaService vagaService = new VagaService();
    private Vaga vaga;

    @BeforeEach
    void setUp() {
        this.vaga = Vaga.builder()
                .id(1)
                .dataHoraEntrada(LocalDateTime.now())
                .cliente(null)
                .ocupado(false)
                .build();
    }

    @Test
    @Order(1)
    @DisplayName("Deveria cadastrar com sucesso a vaga")
    void deveria_cadastrar_com_sucesso_vaga() {
        this.vagaService.cadastrar(this.vaga);
        Mockito.verify(this.vagaRepository).save(BDDMockito.any());
    }
    @Test
    @Order(2)
    @DisplayName("Lista todas as vagas cadastrados")
    void listar() {
        Vaga vaga1 = Vaga.builder()
                .id(1)
                .ocupado(false)
                .cliente(null)
                .dataHoraEntrada(null)
                .build();
        Vaga vaga2 = Vaga.builder()
                .id(2)
                .ocupado(true)
                .cliente(new Cliente(1,"Teste",Status.ATIVO))
                .dataHoraEntrada(LocalDateTime.now())
                .build();
        List<Vaga> lista = new ArrayList<>();
        lista.add(vaga1);
        lista.add(vaga2);
        Mockito.when(this.vagaRepository.findAll()).thenReturn(lista);
        this.vagaService.listar();
        Mockito.verify(this.vagaRepository).findAll();
    }
    @Test
    @Order(3)
    @DisplayName("Deveria cancelar ou inativar a vaga")
    void deveria_cancelar_ou_inativar_vaga() throws NotFoundException {
        var vaga1 = Vaga.builder()
                .id(1)
                .cliente(new Cliente(1,"Teste",Status.ATIVO))
                .status(Status.ATIVO)
                .build();
        Mockito.when(this.vagaRepository.findById(BDDMockito.any())).thenReturn(Optional.ofNullable(vaga1));
        this.vagaService.cancelar(BDDMockito.anyInt());
        Mockito.verify(this.vagaRepository).findById(BDDMockito.anyInt());
        Mockito.verify(this.vagaRepository).save(BDDMockito.any());
    }

    @Test
    @Order(4)
    @DisplayName("Deveria nao cancelar ou inativar a vaga")
    void deveria_nao_cancelar_ou_inativar_vaga_e_retornar_excecao() throws NotFoundException {
        var vaga1 = Vaga.builder()
                .id(1)
                .cliente(new Cliente(1,"Teste",Status.ATIVO))
                .status(Status.ATIVO)
                .build();
        Mockito.when(this.vagaRepository.findById(BDDMockito.any())).thenReturn(Optional.empty());
        Assertions.assertThrows(NotFoundException.class, () ->this.vagaService.cancelar(BDDMockito.anyInt()));
    }

    @Test
    @Order(5)
    @DisplayName("Deveria ocupar a vaga")
    void deveria_ocupar_vaga() throws NotFoundException {
        var vaga1 = Vaga.builder()
                .id(1)
                .cliente(new Cliente(1,"Teste",Status.ATIVO))
                .status(Status.ATIVO)
                .build();
        var cliente1 = Cliente.builder()
                .nome("Teste")
                .status(Status.ATIVO)
                .id(1)
                .build();
        Mockito.when(this.vagaRepository.findById(BDDMockito.any())).thenReturn(Optional.ofNullable(vaga1));
        Mockito.when(this.clienteRepository.findById(BDDMockito.anyInt())).thenReturn(Optional.ofNullable(cliente1));
        this.vagaService.ocuparVaga(1,1);
        Mockito.verify(this.vagaRepository).findById(BDDMockito.anyInt());
        Mockito.verify(this.clienteRepository).findById(BDDMockito.anyInt());
        Mockito.verify(this.vagaRepository).save(BDDMockito.any());
    }

    @Test
    @Order(6)
    @DisplayName("Deveria desocupar a vaga")
    void deveria_desocupar_vaga() throws NotFoundException {
        var vaga1 = Vaga.builder()
                .id(1)
                .cliente(new Cliente(1,"Teste",Status.ATIVO))
                .status(Status.ATIVO)
                .build();
        var cliente1 = Cliente.builder()
                .nome("Teste")
                .status(Status.ATIVO)
                .id(1)
                .build();
        Mockito.when(this.vagaRepository.findById(BDDMockito.any())).thenReturn(Optional.ofNullable(vaga1));
        Mockito.when(this.clienteRepository.findById(BDDMockito.anyInt())).thenReturn(Optional.ofNullable(cliente1));
        this.vagaService.desocuparVaga(1,1);
        Mockito.verify(this.vagaRepository).findById(BDDMockito.anyInt());
        Mockito.verify(this.clienteRepository).findById(BDDMockito.anyInt());
        Mockito.verify(this.vagaRepository).save(BDDMockito.any());
        Mockito.verify(this.historicoRepository).save(BDDMockito.any());
    }

    @Test
    @Order(7)
    @DisplayName("Deveria nao desocupar a vaga devido nao existir o cliente")
    void deveria_nao_desocupar_vaga_devido_nao_existir_cliente() throws NotFoundException {
        var vaga1 = Vaga.builder()
                .id(1)
                .cliente(new Cliente(1,"Teste",Status.ATIVO))
                .status(Status.ATIVO)
                .build();
        var cliente1 = Cliente.builder()
                .nome("Teste")
                .status(Status.ATIVO)
                .id(1)
                .build();
        Mockito.when(this.vagaRepository.findById(BDDMockito.any())).thenReturn(Optional.ofNullable(vaga1));
        Mockito.when(this.clienteRepository.findById(BDDMockito.anyInt())).thenReturn(Optional.empty());
        Assertions.assertThrows(NotFoundException.class, () ->this.vagaService.desocuparVaga(1,1));
    }

    @Test
    @Order(8)
    @DisplayName("Deveria nao desocupar a vaga devido nao existir a vaga")
    void deveria_nao_desocupar_vaga_devido_nao_existir_vaga() throws NotFoundException {
        var vaga1 = Vaga.builder()
                .id(1)
                .cliente(new Cliente(1,"Teste",Status.ATIVO))
                .status(Status.ATIVO)
                .build();
        var cliente1 = Cliente.builder()
                .nome("Teste")
                .status(Status.ATIVO)
                .id(1)
                .build();
        Mockito.when(this.vagaRepository.findById(BDDMockito.any())).thenReturn(Optional.empty());
        Mockito.when(this.clienteRepository.findById(BDDMockito.anyInt())).thenReturn(Optional.ofNullable(cliente1));
        Assertions.assertThrows(NotFoundException.class, () ->this.vagaService.desocuparVaga(1,1));
    }
}