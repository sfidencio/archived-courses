package com.github.sfidencio.estacionamento.services.aceitacao.steps;

import com.github.sfidencio.estacionamento.config.DomainException;
import com.github.sfidencio.estacionamento.config.NotFoundException;
import com.github.sfidencio.estacionamento.model.Cliente;
import com.github.sfidencio.estacionamento.model.Status;
import com.github.sfidencio.estacionamento.model.Vaga;
import com.github.sfidencio.estacionamento.repository.ClienteRepository;
import com.github.sfidencio.estacionamento.repository.HistoricoRepository;
import com.github.sfidencio.estacionamento.repository.VagaRepository;
import com.github.sfidencio.estacionamento.services.ClienteService;
import com.github.sfidencio.estacionamento.services.VagaService;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/*
 *Aqui temos cucumber associado com junit
 */

@SpringBootTest
@CucumberContextConfiguration
@Slf4j
public class Step1_service_en {

    @Mock
    private ClienteRepository clienteRepository;
    @Mock
    private VagaRepository vagaRepository;
    @InjectMocks
    private VagaService vagaService = new VagaService();
    @InjectMocks
    private ClienteService clienteService = new ClienteService();
    private Cliente cliente;
    private List<Cliente> clientes;
    @Mock
    private HistoricoRepository historicoRepository;

    @Given("Dado um cadastro valido")
    public void dado_um_cadastro_valido() {
        cliente = Cliente.builder()
                .id(1)
                .nome("Teste")
                .status(Status.ATIVO)
                .build();
    }

    @When("Quando tenta cadastrar um novo cliente")
    public void quando_tenta_cadastrar_um_novo_cliente() throws DomainException {
        Mockito.when(this.clienteRepository.findById(BDDMockito.any())).thenReturn(Optional.ofNullable(cliente));
        Mockito.when(this.clienteRepository.findAll()).thenReturn(Arrays.asList(new Cliente(1,"Teste 1",Status.ATIVO),new Cliente(2,"Teste 2",Status.INATIVO)));
        this.clienteService.cadastrar(cliente);
    }

    @Then("Entao o cadastro é realizado com sucesso")
    public void entao_o_cadastro_é_realizado_com_sucesso() throws NotFoundException {
        Assertions.assertEquals("Teste",this.clienteService.obterPorId(1).getNome());
    }


    @Given("Dado um cliente valido ja cadastrado")
    public void dado_um_cliente_valido_ja_cadastrado() throws DomainException, NotFoundException {
        cliente = Cliente.builder()
                .id(1)
                .nome("Teste")
                .status(Status.ATIVO)
                .build();
        Mockito.when(this.clienteRepository.findById(BDDMockito.any())).thenReturn(Optional.ofNullable(cliente));
        Mockito.when(this.clienteRepository.findByNome(BDDMockito.any())).thenReturn(Optional.ofNullable(null));
        //Mockito.when(this.clienteRepository.save(BDDMockito.any())).thenReturn(Optional.ofNullable(cliente));
        this.clienteService.cadastrar(cliente);
        var clienteEncontrado = this.clienteService.obterPorId(BDDMockito.any());
        Assertions.assertNotNull(clienteEncontrado);
        //throw new io.cucumber.java.PendingException();
    }
    @When("Quando tenta ocupar vaga")
    public void quando_tenta_ocupar_vaga() throws NotFoundException {
        var vaga = Vaga.builder()
                .id(1)
                .dataHoraEntrada(LocalDateTime.now())
                .ocupado(true)
                .cliente(new Cliente(1,"Teste",Status.ATIVO))
                .status(Status.ATIVO)
                .build();
        Mockito.when(this.vagaRepository.findById(BDDMockito.anyInt())).thenReturn(Optional.ofNullable(vaga));
        Mockito.when(this.clienteRepository.findById(BDDMockito.anyInt())).thenReturn(Optional.ofNullable(cliente));
        this.vagaService.ocuparVaga(1,1);
        //throw new io.cucumber.java.PendingException();
    }
    @Then("Entao a vaga disponivel e ocupada com sucesso")
    public void entao_a_vaga_disponivel_e_ocupada_com_sucesso() throws NotFoundException {
        var vaga = this.vagaService.obterStatus(BDDMockito.anyInt());
        Assertions.assertTrue(vaga.isOcupado());
        //Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
    }

}
