package com.github.sfidencio.estacionamento.services.unitario;

import com.github.sfidencio.estacionamento.config.NotFoundException;
import com.github.sfidencio.estacionamento.model.Cliente;
import com.github.sfidencio.estacionamento.model.Status;
import com.github.sfidencio.estacionamento.model.Vaga;
import com.github.sfidencio.estacionamento.repository.ClienteRepository;
import com.github.sfidencio.estacionamento.repository.HistoricoRepository;
import com.github.sfidencio.estacionamento.repository.VagaRepository;
import com.github.sfidencio.estacionamento.services.ClienteService;
import com.github.sfidencio.estacionamento.services.VagaService;
import org.junit.jupiter.api.*;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@SpringBootTest
class VagaServiceAninhadoTest {

    /*
     *Temos um exemplo do que poderia ser feito de forma estruturada apenas
     *com Junit5 sem o uso do cumcumber, no Entanto, e muito complexo ficar
     *aninhando classes, para estruturar um cenario de teste de aceitacao
     *utilizando apenas Junit.
     *
     * https://dzone.com/articles/7-popular-unit-test-naming
     *
     * padrao de nomeclatura
     *
     */

    @Nested
    @DisplayName("Dado uma vaga a ser cadastrada")
    class CadastroVagaTests {
        Vaga vagaCadastro = Vaga.builder()
                .id(1)
                .cliente(new Cliente(1,"Teste",Status.ATIVO))
                .dataHoraEntrada(null)
                .ocupado(false)
                .build();

        @Mock
        VagaRepository vagaRepository;
        @InjectMocks
        VagaService vagaService = new VagaService();

        @Nested
        @DisplayName("Ao tentar cadastrar")
        class AssertCadastro{
            @Test
            @DisplayName("Deve cadastrar com sucesso")
            void deveria_cadastrar_com_sucesso_vaga() {
                vagaService.cadastrar(vagaCadastro);
                Mockito.verify(vagaRepository).save(BDDMockito.any());
            }
        }

    }


}