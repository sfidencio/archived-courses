package com.github.sfidencio.estacionamento.services.aceitacao.steps;


import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Entao;
import io.cucumber.java.pt.Quando;

public class Step1_service_pt {
    @Dado("um cadastro valido")
    public void dado_um_cadastro_valido() {
        // Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
    }
    @Quando("tenta cadastrar um novo cliente")
    public void quando_tenta_cadastrar_um_novo_cliente() {
        // Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
    }
    @Entao("o cadastro é realizado com sucesso")
    public void entao_o_cadastro_é_realizado_com_sucesso() {
        // Write code here that turns the phrase above into concrete actions
        //throw new io.cucumber.java.PendingException();
    }
}
