package com.github.sfidencio.estacionamento.model;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Cliente {
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Id
    private Integer id;
    @NotNull(message = "Nome e obrigatorio")
    @NotEmpty(message = "Nome e obrigatorio")
    private String nome;
    private Status status = Status.ATIVO;
}
