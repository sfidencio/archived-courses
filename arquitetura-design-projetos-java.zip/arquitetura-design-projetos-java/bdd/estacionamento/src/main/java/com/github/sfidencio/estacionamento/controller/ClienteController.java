package com.github.sfidencio.estacionamento.controller;

import com.github.sfidencio.estacionamento.config.DomainException;
import com.github.sfidencio.estacionamento.config.NotFoundException;
import com.github.sfidencio.estacionamento.model.Cliente;
import com.github.sfidencio.estacionamento.services.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/cliente")
public class ClienteController {
    @Autowired
    private ClienteService service;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void cadastrar(@Valid @RequestBody Cliente cliente) throws DomainException {
        this.service.cadastrar(cliente);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void cancelar(@Valid @PathVariable("id") Integer id) throws NotFoundException {
        this.service.cancelar(id);
    }

    @GetMapping("/lista")
    @ResponseStatus(HttpStatus.OK)
    public List<Cliente> listar() {
       return this.service.listar();
    }
}
