package com.github.sfidencio.estacionamento.controller;

import com.github.sfidencio.estacionamento.model.Historico;
import com.github.sfidencio.estacionamento.repository.HistoricoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/historico")
public class HistoricoController {
    @Autowired
    private HistoricoRepository historicoRepository;

    @GetMapping("/lista")
    @ResponseStatus(HttpStatus.OK)
    public List<Historico> listar() {
        return this.historicoRepository.findAll();
    }

}
