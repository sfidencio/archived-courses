package com.github.sfidencio.estacionamento.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import java.util.Arrays;
import java.util.List;
@Getter
@Setter
public class ApiErrorMessage {
    private int status;
    private List<String> errors;

    public ApiErrorMessage(int httpStatus, List<String> errors) {
        this.status = httpStatus;
        this.errors = errors;
    }


    public ApiErrorMessage(int httpStatus, String error) {
        this.status = httpStatus;
        this.errors = Arrays.asList(error);
    }
}
