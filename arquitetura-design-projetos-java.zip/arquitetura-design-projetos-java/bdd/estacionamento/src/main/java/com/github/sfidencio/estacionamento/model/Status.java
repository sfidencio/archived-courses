package com.github.sfidencio.estacionamento.model;

public enum Status {
    ATIVO,INATIVO
}
