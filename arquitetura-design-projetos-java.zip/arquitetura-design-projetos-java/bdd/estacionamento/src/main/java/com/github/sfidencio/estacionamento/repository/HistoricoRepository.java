package com.github.sfidencio.estacionamento.repository;

import com.github.sfidencio.estacionamento.model.Cliente;
import com.github.sfidencio.estacionamento.model.Historico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HistoricoRepository extends JpaRepository<Historico, Integer> {
}
