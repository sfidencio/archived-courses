package com.github.sfidencio.estacionamento.config;

public class NotFoundException extends Exception {
    public NotFoundException(String message) {
        super(message);
    }
}
