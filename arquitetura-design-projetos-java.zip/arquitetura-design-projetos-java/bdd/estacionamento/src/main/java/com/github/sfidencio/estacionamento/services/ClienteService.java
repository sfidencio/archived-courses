package com.github.sfidencio.estacionamento.services;

import com.github.sfidencio.estacionamento.config.DomainException;
import com.github.sfidencio.estacionamento.config.NotFoundException;
import com.github.sfidencio.estacionamento.model.Cliente;
import com.github.sfidencio.estacionamento.model.Status;
import com.github.sfidencio.estacionamento.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClienteService {
    @Autowired
    private ClienteRepository repository;

    public void cadastrar(Cliente cliente) throws DomainException {
        Optional<Cliente> encontrado = this.repository.findByNome(cliente.getNome());
        if (encontrado.isPresent())
            throw new DomainException("Cliente ja existe!");
        this.repository.save(cliente);
    }

    public void cancelar(Integer id) throws NotFoundException {
        Optional<Cliente> encontrado = this.repository.findById(id);
        if (encontrado.isEmpty())
            throw new NotFoundException("Cliente nao encontrado!");
        encontrado.get().setStatus(Status.INATIVO);
        this.repository.save(encontrado.get());
    }

    public List<Cliente> listar() {
        return this.repository.findAll();
    }

    public Cliente obterPorId(Integer id) throws NotFoundException {
        var cliente = this.repository.findById(id);
        if (cliente.isEmpty())
            throw new NotFoundException("Cliente nao encontrado!");
        return cliente.get();
    }
}
