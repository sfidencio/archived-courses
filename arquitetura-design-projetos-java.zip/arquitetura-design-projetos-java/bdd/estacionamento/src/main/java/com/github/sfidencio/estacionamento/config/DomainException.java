package com.github.sfidencio.estacionamento.config;

public class DomainException extends Exception {
    public DomainException(String message) {
        super(message);
    }
}
