package com.github.sfidencio.estacionamento.controller;

import com.github.sfidencio.estacionamento.config.NotFoundException;
import com.github.sfidencio.estacionamento.model.Vaga;
import com.github.sfidencio.estacionamento.services.VagaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/vaga")
public class VagaController {
    @Autowired
    private VagaService service;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void cadastrar(@Valid  @RequestBody Vaga vaga) {
        this.service.cadastrar(vaga);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void cancelar(@Valid @PathVariable("id") Integer id) throws NotFoundException {
        this.service.cancelar(id);
    }

    @GetMapping("/lista")
    @ResponseStatus(HttpStatus.OK)
    public List<Vaga> listar() {
        return this.service.listar();
    }

    @PatchMapping("/ocupa/{id-vaga}/{id-cliente}")
    public void ocuparVaga(@Valid @PathVariable("id-vaga") Integer idVaga, @PathVariable("id-cliente") Integer idCliente) throws NotFoundException {
        this.service.ocuparVaga(idVaga, idCliente);
    }
    @PatchMapping("/desocupa/{id-vaga}/{id-cliente}")
    public void desocuparVaga(@Valid @PathVariable("id-vaga") Integer idVaga, @PathVariable("id-cliente") Integer idCliente) throws NotFoundException {
        this.service.desocuparVaga(idVaga, idCliente);
    }
}
