package com.github.sfidencio.estacionamento.services;

import com.github.sfidencio.estacionamento.config.NotFoundException;
import com.github.sfidencio.estacionamento.model.Cliente;
import com.github.sfidencio.estacionamento.model.Historico;
import com.github.sfidencio.estacionamento.model.Status;
import com.github.sfidencio.estacionamento.model.Vaga;
import com.github.sfidencio.estacionamento.repository.ClienteRepository;
import com.github.sfidencio.estacionamento.repository.HistoricoRepository;
import com.github.sfidencio.estacionamento.repository.VagaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VagaService {
    @Autowired
    private VagaRepository repository;
    @Autowired
    private ClienteRepository clienteRepository;
    @Autowired
    private HistoricoRepository historicoRepository;

    public void cadastrar(Vaga vaga) {
        this.repository.save(vaga);
    }
    public List<Vaga> listar() {
        return this.repository.findAll();
    }

    public void cancelar(Integer id) throws NotFoundException {
        var encontrada = this.repository.findById(id);
        if(encontrada.isEmpty())
            throw new NotFoundException("Vaga nao encontrada!");
        encontrada.get().setStatus(Status.INATIVO);
        this.repository.save(encontrada.get());
    }

    public void ocuparVaga(Integer idVaga, Integer idCliente) throws NotFoundException {
        Optional<Cliente> cliente = this.clienteRepository.findById(idCliente);
        Optional<Vaga> vaga = this.repository.findById(idVaga);
        if(cliente.isEmpty())
            throw  new NotFoundException("Cliente nao encontrado!");
        if(vaga.isEmpty())
            throw  new NotFoundException("Vaga nao encontrada!");

        vaga.get().setCliente(cliente.get());
        vaga.get().setOcupado(true);
        vaga.get().setDataHoraEntrada(LocalDateTime.now());

        this.repository.save(vaga.get());
    }

    @Transactional
    public void desocuparVaga(Integer idVaga, Integer idCliente) throws NotFoundException {
        Optional<Cliente> cliente = this.clienteRepository.findById(idCliente);
        Optional<Vaga> vaga = this.repository.findById(idVaga);
        if(cliente.isEmpty())
            throw  new NotFoundException("Cliente nao encontrado!");
        if(vaga.isEmpty())
            throw  new NotFoundException("Vaga nao encontrada!");

        var historico = Historico.builder()
                .cliente(vaga.get().getCliente().getNome())
                .dataHoraEntrada(vaga.get().getDataHoraEntrada())
                .dataHoraSaida(LocalDateTime.now())
                .build();

        this.historicoRepository.save(historico);




        vaga.get().setCliente(null);
        vaga.get().setOcupado(false);
        vaga.get().setDataHoraEntrada(null);


        this.repository.save(vaga.get());
    }

    public Vaga obterStatus(Integer id) throws NotFoundException {
        var vaga = this.repository.findById(id);
        if(vaga.isEmpty())
            throw  new NotFoundException("Vaga nao encontrada!");
        return vaga.get();
    }

}
