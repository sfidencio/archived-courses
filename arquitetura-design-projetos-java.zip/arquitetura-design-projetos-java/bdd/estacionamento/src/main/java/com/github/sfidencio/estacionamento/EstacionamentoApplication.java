package com.github.sfidencio.estacionamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 *https://www.baeldung.com/vaadin
 */

@SpringBootApplication
public class EstacionamentoApplication {
    public static void main(String[] args) {
        SpringApplication.run(EstacionamentoApplication.class, args);
    }

}
