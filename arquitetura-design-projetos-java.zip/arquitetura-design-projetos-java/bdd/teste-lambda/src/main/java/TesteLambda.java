import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class TesteLambda {

    private static List<Produto> lista;

    public static void main(String[] args) {
        popularProdutos();

        Iterator<Produto> itx = lista.listIterator();
        while (itx.hasNext())
            System.out.println(itx.next().getPreco());

        System.out.println();
        System.out.println();

        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i).getPreco());
        }

        System.out.println();
        System.out.println();

        for (Produto produto : lista) {
            System.out.println(produto.getPreco());
        }

        System.out.println();
        System.out.println();


        lista.forEach(item -> System.out.println(item.getPreco()));

        System.out.println();
        System.out.println();

        lista.forEach(Produto::getPreco);

        var result = lista.stream().filter(item->item.getPreco().doubleValue() > 7.00).collect(Collectors.toList());
        System.out.println(result);

    }

    private static void  popularProdutos() {
        lista = new ArrayList<>(0);
        lista.add(new Produto(1,"Feijao",new BigDecimal("7.89")));
        lista.add(new Produto(2,"Arroz",new BigDecimal("12.30")));
        lista.add(new Produto(3,"Macarrao",new BigDecimal("5.20")));
        lista.add(new Produto(3,"Extrato Tomate",new BigDecimal("17.23")));
    }
}
